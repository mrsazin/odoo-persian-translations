## Module <login_pos_direct>

#### 11.01.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Pos Direct Login

#### 29.03.2024
#### Version 17.0.1.0.1
#### BUGFIX
- Added a website parameter to the login route to solve the issue related to the website login.