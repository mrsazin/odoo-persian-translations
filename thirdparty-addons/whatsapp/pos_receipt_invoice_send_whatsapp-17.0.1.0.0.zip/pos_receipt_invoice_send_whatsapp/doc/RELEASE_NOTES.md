## Module <pos_receipt_invoice_send_whatsapp>
#### 12.06.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Send POS Receipt and Invoice via WhatsApp
