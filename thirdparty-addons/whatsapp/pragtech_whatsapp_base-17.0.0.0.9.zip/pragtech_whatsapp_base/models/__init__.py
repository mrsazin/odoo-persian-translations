from . import whatsapp_templates
from . import whatsapp_template_call_to_action
from . import whatsapp_instance
from . import whatsapp_messages
from . import res_users
from . import res_partner
from . import res_company
from . import terminal_log