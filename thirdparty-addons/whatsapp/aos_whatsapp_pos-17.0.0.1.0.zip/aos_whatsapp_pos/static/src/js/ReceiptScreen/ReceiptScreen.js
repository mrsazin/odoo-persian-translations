/** @odoo-module */

import { ReceiptScreen } from "@point_of_sale/app/screens/receipt_screen/receipt_screen";
import { _t } from "@web/core/l10n/translation";
import { patch } from "@web/core/utils/patch";

import { useState } from "@odoo/owl";

patch(ReceiptScreen.prototype, {
    setup() {
        super.setup(...arguments);
        const partner = this.currentOrder.get_partner();
        const orderName = this.currentOrder.get_name();
        const pos_config = this.pos.config;
        let message = pos_config.whatsapp_default_message.replace("_CUSTOMER_", partner && partner.name || 'Customer');
        // console.log('=message=',message)
        // this.orderUiState.inputMessage = message + ' ' + orderName +'.';
        this.orderUiState = useState({
            inputWhatsapp: (partner && partner.whatsapp) || "",
            inputMessage: message  + ' ' + orderName +'.',
            isSending: false,
            whatsappButtonDisabled: false,
            whatsappNotice: "",
            whatsappSuccessful: null,
        });
    },

    get is_valid_mobile() {
        const value = this.orderUiState.inputWhatsapp;
        if (value) {
            const valueLen = value.replace(/[^0-9]/g, "").length;
            return valueLen > 8 && valueLen < 15;
        }
        return false;
    },

    _updateWhatsappState(status, msg) {
        this.orderUiState.whatsappSuccessful = status;
        this.orderUiState.whatsappNotice = msg;
    },

    onInputWhatsapp(ev) {
        this.orderUiState.whatsappButtonDisabled = false;
        this.orderUiState.inputWhatsapp = ev.target.value;
    },

    async onSendWhatsapp() {
        if (this.orderUiState.isSending) {
            this._updateWhatsappState(false, _t("Sending in progress"));
            return;
        }
        this.orderUiState.isSending = true;
        this.orderUiState.whatsappNotice = "";

        if (!this.is_valid_mobile) {
            this._updateWhatsappState(false, _t("Invalid Number"));
            this.orderUiState.isSending = false;
            return;
        }

        // Delay to allow the user to see the wheel that informs that the whatsapp message will be sent
        setTimeout(async () => {
            try {
                await this._sendWhatsappToCustomer();
                this._updateWhatsappState(true, _t("WhatsApp sent"));
            } catch (error) {
                console.error(error);
                this._updateWhatsappState(
                    false,
                    _t("Something went wrong, please check the number and try again.")
                );
                this.orderUiState.whatsappButtonDisabled = true;
            }
            this.orderUiState.isSending = false;
        }, 1000);
    },

    async _sendWhatsappToCustomer() {
        const partner = this.currentOrder.get_partner();
        const orderPartner = {
            name: partner ? partner.name : this.orderUiState.inputWhatsapp,
            whatsapp: this.orderUiState.inputWhatsapp,
            message: this.orderUiState.inputMessage,
        };
        await this.sendToCustomer(orderPartner, "action_whatsapp_to_customer");
    },
});
