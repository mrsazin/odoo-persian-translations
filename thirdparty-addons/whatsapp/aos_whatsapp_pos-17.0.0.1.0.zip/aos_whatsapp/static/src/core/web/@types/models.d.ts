declare module "models" {
    export interface DiscussApp {
        livechat: DiscussAppCategory,
    }
    export interface Thread {
        anonymous_country: Object,
        anonymous_name: String,
    }
}
