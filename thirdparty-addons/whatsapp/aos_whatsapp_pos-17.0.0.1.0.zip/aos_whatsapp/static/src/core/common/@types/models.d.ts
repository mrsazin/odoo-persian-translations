declare module "models" {
    export interface Thread {
        operator: Persona,
    }
}
