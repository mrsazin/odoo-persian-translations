## Module <restrict_web_debug>

#### 01.01.2024
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Userwise Developer Mode Restriction
