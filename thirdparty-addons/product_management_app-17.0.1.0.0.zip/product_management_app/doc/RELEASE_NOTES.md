## Module <product_management_app>

#### 24.01.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Product Management 
