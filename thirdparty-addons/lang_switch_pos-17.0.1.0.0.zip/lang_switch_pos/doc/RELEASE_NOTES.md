## Module <lang_switch_pos>

#### 11.03.2024
#### Version 17.0.1.0.0
##### ADD
- Initial Commit for POS Language Switcher
