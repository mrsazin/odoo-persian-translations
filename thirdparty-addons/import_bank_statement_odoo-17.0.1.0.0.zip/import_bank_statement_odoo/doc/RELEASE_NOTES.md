## Module <import_bank_statement_odoo>
#### 06.02.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Import Bank Statement
