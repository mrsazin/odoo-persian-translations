## Module <pos_magnify_image>

#### 02.01.2024
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Pos Product Magnify Image
