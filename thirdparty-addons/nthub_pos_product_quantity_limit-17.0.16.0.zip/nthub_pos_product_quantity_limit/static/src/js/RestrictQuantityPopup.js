/** @odoo-module **/

import { AbstractAwaitablePopup } from "@point_of_sale/app/popup/abstract_awaitable_popup";

class RestrictQuantityPopup extends AbstractAwaitablePopup { }
RestrictQuantityPopup.template = 'RestrictQuantityPopup';
export default RestrictQuantityPopup;
