/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import RestrictQuantityPopup from "@nthub_pos_product_quantity_limit/js/RestrictQuantityPopup"
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";

patch(ProductScreen.prototype, {
    async onNumpadClick(buttonValue) {
        if (["quantity", "discount", "price"].includes(buttonValue)) {
            this.numberBuffer.capture();
            this.numberBuffer.reset();
            this.pos.numpadMode = buttonValue;
            return;
        }
        else{
        var order_line = this.currentOrder.get_selected_orderline();
        var product = order_line ? order_line.product : null;
        if (order_line) {
            var qty_val = parseFloat( order_line.quantity.toString() + buttonValue)
            var product_qty = this._product_order_quantity(this.currentOrder, product, parseFloat(qty_val))
            if (this.pos.numpadMode === 'quantity') {
//                if (this.env.pos.config.product_quantity_limit && product.limit_quantity > 0 && (parseFloat(val) > product.limit_quantity || product_qty + parseFloat(val) > product.limit_quantity)) {
                if (this.pos.config.product_quantity_limit && product.limit_quantity > 0 && (parseFloat(qty_val) > product.limit_quantity || product_qty + parseFloat(qty_val) > product.limit_quantity)) {
                    this.numberBuffer.reset();
                    this.popup.add(RestrictQuantityPopup, {
                        body: product.display_name + 'is Over the Quantity Limit equal ' + product.limit_quantity,
                        pro_id: product.id
                    });
                }
                else {
                    await super.onNumpadClick(buttonValue);
                }
            }
            else {
                await super.onNumpadClick(buttonValue);
            }
        }
        }
    },
    _product_order_quantity(currentOrder, product,val) {
        var sum_qty = 0
        for (let line of currentOrder.orderlines) {
            if (line.product.id == product.id) {
                sum_qty = sum_qty + line.quantity

            }
        }
        return val > 1 ? sum_qty - currentOrder.selected_orderline.quantity : sum_qty
    }
});
