/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import RestrictQuantityPopup from "@nthub_pos_product_quantity_limit/js/RestrictQuantityPopup"
import { PosStore } from "@point_of_sale/app/store/pos_store";

patch(PosStore.prototype, {
    async addProductToCurrentOrder(...args) {
        const product = args['0'];
        const currentOrder = this.get_order();
        var product_qty = this._product_order_quantity(currentOrder, product, 1) + 1;
        if (this.config.product_quantity_limit && product.limit_quantity > 0 && product_qty > product.limit_quantity) {
            this.popup.add(RestrictQuantityPopup, {
                body: product.display_name + 'is Over the Quantity Limit equal ' + product.limit_quantity,
                pro_id: product.id
            });
            return;
        }
        if (this.config.is_pos_bill_quantity_limit && this.config.pos_bill_quantity_limit > 0 && currentOrder.selected_orderline ? currentOrder.selected_orderline.product.id !== product.id : true) {
            if(!currentOrder.orderlines.some(orderline => orderline.product.id === product.id)){
                var orderlines_length = currentOrder.orderlines.length;
                if (orderlines_length + 1 > this.config.pos_bill_quantity_limit){
                    this.popup.add(RestrictQuantityPopup, {
                    body: 'Can not add more than '+ this.config.pos_bill_quantity_limit +' Products',
                    pro_id: product.id
                    });
                    return;
                    }
                else {
                    await super.addProductToCurrentOrder(...args)
                }
            }
            else {
                await super.addProductToCurrentOrder(...args)
            }
        }
        else{
            await super.addProductToCurrentOrder(...args)
        }
    },

    _product_order_quantity(currentOrder, product,val) {
        var sum_qty = 0
        for (let line of currentOrder.orderlines) {
            if (line.product.id == product.id) {
                sum_qty = sum_qty + line.quantity
            }
        }
        return val > 1 ? sum_qty - currentOrder.selected_orderline.quantity : sum_qty
    }
});
