# -*- coding: utf-8 -*-

from . import pos_session
from . import pos_config
from . import res_config_settings
from . import product_product
from . import account_move_line
