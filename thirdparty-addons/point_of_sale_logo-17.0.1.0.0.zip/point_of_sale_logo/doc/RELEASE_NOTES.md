## Module <point_of_sale_logo>

#### 29.11.2023
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Point of Sale Logo
