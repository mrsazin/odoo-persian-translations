## Module <odoo_read_messages>

#### 10.05.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Odoo Read Messages.
