## Module <multi_barcodes_pos>

#### 17.02.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for POS Product Multi Barcode
