## Module <pos_restrict_product_stock>

#### 08.03.2024
#### Version 17.0.1.0.0
#### ADD
- Initial Commit for Display Stock in POS | Restrict Out-of-Stock Products in POS
