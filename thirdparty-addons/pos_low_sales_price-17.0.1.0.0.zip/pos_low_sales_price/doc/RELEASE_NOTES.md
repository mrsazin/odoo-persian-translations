## Module <pos_low_sales_price>

#### 17.11.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Pos Alert in Low Sales Price
