=====================
**Custom Background**
=====================

**Description**
***************
* Custom Background allows for the customization of report backgrounds based on the company, language, and fixed page number.

**Author**
**********
* BizzAppDev Systems Pvt. Ltd.

**Used by**
***********
* BizzAppDev Systems Pvt. Ltd.

**Installation**
****************
* #N/A

**Configuration**
*****************
* #N/A

**Known issues/Roadmap**
************************
* #N/A

**Changelog**
*************
* 13-05-2024 - T7747 - KRT - Migrate custom_background from 16.0 to 17.0.

