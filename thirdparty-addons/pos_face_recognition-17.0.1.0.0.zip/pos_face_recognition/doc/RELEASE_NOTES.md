## Module <pos_face_recognition>

#### 16.04.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Pos Face Recognition
