======================
Rewards Codes Addon For Point of Sale
======================
This module helps you to reward your customers through Rewards Codes

Tech
====
* [Python] - Models
* [XML] - Odoo views

Installation
============
- www.odoo.com/documentation/12.0/setup/install.html
- Install our custom addon

Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Credits
=======
* Rewards Codes <https://rewards.codes>

Maintainer
----------

This module is maintained by Rewards Codes.

For support and more information, please visit https://rewards.codes.