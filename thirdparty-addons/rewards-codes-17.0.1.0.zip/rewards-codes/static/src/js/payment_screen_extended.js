/** @odoo-module **/

import { PaymentScreen } from '@point_of_sale/app/screens/payment_screen/payment_screen';
import { patch } from '@web/core/utils/patch';
import { jsonrpc } from "@web/core/network/rpc_service";
import { setQRData, getRwCConfig } from './rwc_state';

patch(PaymentScreen.prototype, {
    async validateOrder(isForceValidate) {
        const order = this.pos.get_order();

        // Generate QR code before validating the order
        await this.generateQRCode(order);

        // Call the original validateOrder function
        super.validateOrder(isForceValidate);
    },

    async generateQRCode(order) {
        console.log("ORDER");
        console.log(getRwCConfig());
        try {
            const response = await jsonrpc('/web/dataset/call_kw', {
                model: 'rewardscodes.config',
                method: 'get_all',
                args: [],
                kwargs: {},
            });

            const data = JSON.parse(response);

            if (!data || !data.phone || !data.mode || !data.api_key || !data.default_phone_code) {
                console.log("Rewards Codes has not been configured!");
                return;
            }

            const partner = data['phone'][0];
            const apiKey = data['api_key'][0];
            const mode = data['mode'][0];
            const qrEnabled = data['qr'][0];

            if (!qrEnabled) {
                console.log("Rewards Codes QR not set");
                setQRData({disabled: true});
                return;
            }

            var quantity = 0;
            if(mode === 'visit') quantity = 1
            else if(mode === 'product') {
                quantity = order.orderlines.reduce((sum, line) => { return sum + parseFloat(line.quantity) }, 0);
            } else {
                setQRData({disabled: true});
                return;
            }
            const code = await getOneUseQRCode(partner, quantity, apiKey);
            // Store QR code data in the shared state
            setQRData({code: code, partner: partner, disabled: false});
            await new Promise(resolve => setTimeout(resolve, 300));

        } catch (error) {
            setQRData({disabled: true});
            console.error("Failed to get QR code:", error);
        }
    }
});

async function getOneUseQRCode(partner, quantity, apiKey) {
    const url = `https://apig.systems:8000/rwc/get_one_use_qr_code?id=${encodeURIComponent(partner)}&quantity=${quantity}`;
    return new Promise((resolve, reject) => {
        $.ajax({
            type: "GET",
            url: url,
            headers: {
                'rwc-id': apiKey,
                'Content-Type': 'application/json'
            },
            success: function(data) {
                if (data.status === 'error') {
                    reject(data.message);
                } else {
                    resolve(data.code);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                reject(new Error(`Request failed with status: ${textStatus}`));
            }
        });
    });
}
