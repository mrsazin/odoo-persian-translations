/** @odoo-module **/

import { OrderReceipt } from '@point_of_sale/app/screens/receipt_screen/receipt/order_receipt';
import { patch } from '@web/core/utils/patch';
import { useRef, onMounted, useState } from '@odoo/owl';
import { getQRData } from './rwc_state';

patch(OrderReceipt.prototype, {
    setup() {
        super.setup();

        var qrData = getQRData();
        this.state = useState({ qr: !qrData['disabled'] });
        if(qrData['disabled']) return;
        
        
        const qrCodeContainerRef = useRef('qr-code-container');
        const orderData = this.props.data;
        const partner = encodeURIComponent(qrData['partner']);
        const code = qrData['code'];
        let totalQuantity = parseInt(orderData.orderlines.reduce((sum, line) => {
            return sum + parseFloat(line.qty);
        }, 0));

        qrData = `https://app.rewards.codes/?id=${partner}&code=${code}&quantity=${totalQuantity}&qr=one_use`;

        onMounted(() => {
            new QRCode(qrCodeContainerRef.el, {
                text: qrData,
                // width: 160,
                // height: 160,
            });
        });
    },
});

console.log("OrderReceipt Patched");