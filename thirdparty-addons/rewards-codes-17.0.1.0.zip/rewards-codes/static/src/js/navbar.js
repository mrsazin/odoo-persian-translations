/** @odoo-module */

import { Navbar } from "@point_of_sale/app/navbar/navbar";
import { patch } from "@web/core/utils/patch";
import { _t } from "@web/core/l10n/translation";
import { jsonrpc } from "@web/core/network/rpc_service";  // Import jsonrpc
import { setRwCConfig, getRwCConfig } from './rwc_state';

patch(Navbar.prototype, {
    components: {
        ...Navbar.prototype.components,
        // CreateProductPopup,
    },
    setup() {
        super.setup();

        jsonrpc('/web/dataset/call_kw', {
            model: 'rewardscodes.config',
            method: 'get_all',
            args: [],
            kwargs: {},
        })
        .then(function (response) {
            // Parse response as JSON
            var data = JSON.parse(response);
            console.log(data);
    
            if (!data || !data.phone || !data.mode || !data.api_key || !data.default_phone_code) {
                showError("Rewards Codes has not been configured!");
                return;
            }
    
            var partner = data['phone'][0];
            var apiKey = data['api_key'][0];
            var code = data['default_phone_code'][0];
            var mode = data['mode'][0];
            var qr = data['qr'][0];
    
            if ([partner, apiKey, code, qr, mode].includes(undefined) || [partner, apiKey, code, qr, mode].includes([])) {
                showError("Rewards Codes has not been configured!");
                return;
            }
    
            console.log("DATA RETRIEVED, saving...");
            setRwCConfig({ partner, apiKey, code, qr, mode })
            getRewardsLeft(partner, apiKey)
        })
        .catch(function (error) {
            showError("An error occurred while retrieving Rewards Codes configuration!");
            console.error(error);
        });
    },
    onRewardsCodesButtonClick() {
        const config = getRwCConfig();
        console.log(config);
        openRewardsCodesDialog(config['partner'], config['apiKey'], config['code'], config['qr']);
    }
});

function getRwCData() {
    console.log("getRwCData");
    jsonrpc('/web/dataset/call_kw', {
        model: 'rewardscodes.config',
        method: 'get_all',
        args: [],
        kwargs: {},
    })
    .then(function (response) {
        // Parse response as JSON
        var data = JSON.parse(response);
        console.log(data);

        if (!data || !data.phone || !data.api_key || !data.default_phone_code) {
            showError("Rewards Codes has not been configured!");
            return;
        }

        var partner = data['phone'][0];
        var apiKey = data['api_key'][0];
        var code = data['default_phone_code'][0];
        var qr = data['qr'][0];

        if ([partner, apiKey, code, qr].includes(undefined) || [partner, apiKey, code, qr].includes([])) {
            showError("Rewards Codes has not been configured!");
            return;
        }

        console.log("DATA RETRIEVED, rendering RwC UI");
        // renderRewardsCodesElements(partner, apiKey, code, qr);
        openRewardsCodesDialog(partner, apiKey, code, qr);
        getRewardsLeft(partner, apiKey)
    })
    .catch(function (error) {
        showError("An error occurred while retrieving Rewards Codes configuration!");
        console.error(error);
    });
}



function showError(message) {
    console.log("ERROR, could not get RwC data");

    // Remove any existing error modals
    const existingModal = document.getElementById('errorModal');
    if (existingModal) {
        existingModal.remove();
    }

    // Create the modal structure
    const modal = document.createElement('div');
    modal.className = 'modal-dialog position-absolute start-0 top-0 d-flex align-items-center justify-content-center h-100 w-100 mw-100 m-0 p-0 pe-auto bg-dark bg-opacity-50';
    modal.id = 'errorModal';
    modal.setAttribute('role', 'dialog');
    modal.style.zIndex = '10001';

    const popup = document.createElement('div');
    popup.className = 'popup product-info-popup';

    const modalHeader = document.createElement('div');
    modalHeader.className = 'modal-header';

    const modalTitle = document.createElement('h4');
    modalTitle.className = 'modal-title';
    modalTitle.textContent = 'Error';
    modalTitle.style.fontSize = '28px'; // Larger title size

    const closeButton = document.createElement('div');
    closeButton.className = 'btn';
    closeButton.style.cursor = 'pointer';
    const closeIcon = document.createElement('i');
    closeIcon.className = 'fa fa-times';
    closeIcon.setAttribute('aria-hidden', 'true');
    closeButton.appendChild(closeIcon);

    closeButton.addEventListener('click', () => {
        document.body.classList.remove('modal-open');
        document.getElementById('errorModal').remove();
    });

    const modalBody = document.createElement('main');
    modalBody.className = 'body modal-body overflow-auto';

    const errorMessage = document.createElement('div');
    errorMessage.className = 'rwc-error-lbl';
    errorMessage.style.color = 'red';
    errorMessage.style.fontSize = '20px'; // Smaller content text size
    errorMessage.style.textAlign = 'center';
    errorMessage.style.width = '-webkit-fill-available';
    errorMessage.style.padding = '7px';
    errorMessage.textContent = message;

    // Assemble the modal structure
    modalHeader.appendChild(modalTitle);
    modalHeader.appendChild(closeButton);
    modalBody.appendChild(errorMessage);
    popup.appendChild(modalHeader);
    popup.appendChild(modalBody);
    modal.appendChild(popup);
    document.body.appendChild(modal);

    // Show the modal
    document.body.classList.add('modal-open');
    modal.style.display = 'flex';

    // Ensure modal is cleaned up after being hidden
    modal.addEventListener('hidden.bs.modal', () => {
        modal.remove();
    });
}

function openRewardsCodesDialog(partner, apiKey, code, qr) {
    document.querySelectorAll('.rwc-button').forEach(el => el.remove());
    const existingModal = document.getElementById('exampleModal');
    if (existingModal) existingModal.remove();

    // Create the modal structure
    console.log("CREATE MODAL")
    const modal = document.createElement('div');
    modal.className = 'modal-dialog position-absolute start-0 top-0 d-flex align-items-center justify-content-center h-100 w-100 mw-100 m-0 p-0 pe-auto bg-dark bg-opacity-50';
    modal.id = 'exampleModal';
    modal.setAttribute('role', 'dialog');
    modal.style.zIndex = '10001';

    const popup = document.createElement('div');
    popup.className = 'popup product-info-popup';

    const modalHeader = document.createElement('div');
    modalHeader.className = 'modal-header';
    modalHeader.style.backgroundColor = '#72246c';
    modalHeader.style.borderRadius = '3px';
    modalHeader.style.height = '60px';
    modalHeader.style.color = 'white';
    modalHeader.style.display = 'flex';
    modalHeader.style.justifyContent = 'space-between';
    modalHeader.style.padding = '12px';

    const modalTitle = document.createElement('strong');
    modalTitle.className = 'modal-title';
    modalTitle.textContent = 'RwC';
    modalTitle.style.alignSelf = 'center';

    const closeButton = document.createElement('div');
    closeButton.className = 'btn rwc-close rwc-btn';
    closeButton.style.padding = '0px';
    closeButton.style.borderRadius = '50%';
    closeButton.style.alignSelf = 'center';
    closeButton.style.fontSize = '28px';
    closeButton.style.cursor = 'pointer';
    closeButton.style.width = '40px';
    const closeIcon = document.createElement('i');
    closeIcon.className = 'fa fa-close';
    closeIcon.setAttribute('aria-hidden', 'true');
    closeButton.appendChild(closeIcon);

    closeButton.addEventListener('click', () => {
        document.body.classList.remove('modal-open');
        document.getElementById('exampleModal').remove();
    });

    modalHeader.appendChild(modalTitle);
    modalHeader.appendChild(closeButton);

    const modalBody = document.createElement('div');
    modalBody.className = 'modal-body';
    modalBody.style.padding = '12px';
    modalBody.style.overflowY = 'scroll';
    modalBody.style.flexGrow = '2';
    modalBody.style.backgroundColor = 'white';
    modalBody.style.display = 'flex';
    modalBody.style.flexFlow = 'column';

    const rewardsView = document.createElement('div');
    rewardsView.id = 'rewardsView';
    rewardsView.style.display = 'flex';
    rewardsView.style.flexFlow = 'column';

    const rewardsPhoneLabel = document.createElement('span');
    rewardsPhoneLabel.style.fontSize = 'larger';
    rewardsPhoneLabel.style.fontWeight = 'bold';
    rewardsPhoneLabel.textContent = 'Número telefónico';

    const rewardsPhoneDiv = document.createElement('div');
    rewardsPhoneDiv.style.display = 'flex';

    const rewardsPhoneInput = document.createElement('input');
    rewardsPhoneInput.style.margin = '5px';
    rewardsPhoneInput.type = 'text';
    rewardsPhoneInput.value = '+52';
    rewardsPhoneInput.id = 'rewardsPhone';

    const rewardsButton = document.createElement('button');
    rewardsButton.className = 'rwc-btn';
    rewardsButton.id = 'rewardsButton';
    rewardsButton.type = 'button';
    rewardsButton.textContent = 'Registrar número';

    rewardsPhoneDiv.appendChild(rewardsPhoneInput);
    rewardsPhoneDiv.appendChild(rewardsButton);
    rewardsView.appendChild(rewardsPhoneLabel);
    rewardsView.appendChild(rewardsPhoneDiv);

    const codesView = document.createElement('div');
    codesView.id = 'codesView';
    codesView.style.display = 'flex';
    codesView.style.flexFlow = 'column';

    const codesPhoneLabel = document.createElement('span');
    codesPhoneLabel.style.fontSize = 'larger';
    codesPhoneLabel.style.fontWeight = 'bold';
    codesPhoneLabel.textContent = 'Número telefónico';

    const codesPhoneDiv = document.createElement('div');
    codesPhoneDiv.style.display = 'flex';

    const codesPhoneInput = document.createElement('input');
    codesPhoneInput.style.margin = '5px';
    codesPhoneInput.type = 'text';
    codesPhoneInput.value = '+52';
    codesPhoneInput.id = 'codesPhone';

    const codesConsultButton = document.createElement('button');
    codesConsultButton.className = 'rwc-btn';
    codesConsultButton.id = 'codesConsultButton';
    codesConsultButton.type = 'button';
    codesConsultButton.textContent = 'Consultar Saldo';

    codesPhoneDiv.appendChild(codesPhoneInput);
    codesPhoneDiv.appendChild(codesConsultButton);
    codesView.appendChild(codesPhoneLabel);
    codesView.appendChild(codesPhoneDiv);

    const codesCodeLabel = document.createElement('span');
    codesCodeLabel.style.margin = '5px 0px';
    codesCodeLabel.style.fontSize = 'larger';
    codesCodeLabel.style.fontWeight = 'bold';
    codesCodeLabel.textContent = 'Código';

    const codesCodeDiv = document.createElement('div');
    codesCodeDiv.style.display = 'flex';

    const codesCodeInput = document.createElement('input');
    codesCodeInput.style.margin = '5px';
    codesCodeInput.type = 'text';
    codesCodeInput.id = 'codesCode';

    const codesSendButton = document.createElement('button');
    codesSendButton.className = 'rwc-btn';
    codesSendButton.id = 'codesSendButton';
    codesSendButton.type = 'button';
    codesSendButton.textContent = 'Enviar código';

    codesCodeDiv.appendChild(codesCodeInput);
    codesCodeDiv.appendChild(codesSendButton);
    codesView.appendChild(codesCodeLabel);
    codesView.appendChild(codesCodeDiv);

    const codesVisitsLabel = document.createElement('span');
    codesVisitsLabel.style.margin = '5px 0px';
    codesVisitsLabel.style.fontSize = 'larger';
    codesVisitsLabel.style.fontWeight = 'bold';
    codesVisitsLabel.textContent = 'Número de visitas';

    const codesVisitsDiv = document.createElement('div');
    codesVisitsDiv.style.display = 'flex';

    const codesVisitsInput = document.createElement('input');
    codesVisitsInput.style.margin = '5px';
    codesVisitsInput.type = 'text';
    codesVisitsInput.id = 'codesVisits';

    const codesRedeemButton = document.createElement('button');
    codesRedeemButton.className = 'rwc-btn';
    codesRedeemButton.id = 'codesRedeemButton';
    codesRedeemButton.type = 'button';
    codesRedeemButton.textContent = 'Canjear Premio';

    codesVisitsDiv.appendChild(codesVisitsInput);
    codesVisitsDiv.appendChild(codesRedeemButton);
    codesView.appendChild(codesVisitsLabel);
    codesView.appendChild(codesVisitsDiv);
    codesView.style.display = 'none';

    modalBody.appendChild(rewardsView);
    modalBody.appendChild(codesView);
    modalBody.appendChild(document.createElement('div')).className = 'rwc-message';

    const modalFooter = document.createElement('div');
    modalFooter.className = 'rwc-modal-footer';
    modalFooter.style.display = 'flex';
    modalFooter.style.backgroundColor = '#72246c';
    modalFooter.style.color = 'white';
    modalFooter.style.padding = '0px !important';

    const btnRewardsView = document.createElement('div');
    btnRewardsView.className = 'rwc-btn-footer';
    btnRewardsView.id = 'btnRewardsView';
    btnRewardsView.style.margin = '0';
    btnRewardsView.style.display = 'flex';
    btnRewardsView.style.justifyContent = 'center';
    btnRewardsView.style.flexGrow = '2';
    btnRewardsView.style.alignSelf = 'center';
    btnRewardsView.style.fontSize = 'x-large';
    btnRewardsView.textContent = 'Rewards';

    const btnCodesView = document.createElement('div');
    btnCodesView.className = 'rwc-btn-footer';
    btnCodesView.id = 'btnCodesView';
    btnCodesView.style.margin = '0';
    btnCodesView.style.display = 'flex';
    btnCodesView.style.justifyContent = 'center';
    btnCodesView.style.flexGrow = '2';
    btnCodesView.style.alignSelf = 'center';
    btnCodesView.style.fontSize = 'x-large';
    btnCodesView.textContent = 'Codes';

    modalFooter.appendChild(btnRewardsView);
    modalFooter.appendChild(btnCodesView);

    popup.appendChild(modalHeader);
    popup.appendChild(modalBody);
    popup.appendChild(modalFooter);
    modal.appendChild(popup);
    document.body.appendChild(modal);

    // Event listeners
    btnRewardsView.addEventListener('click', () => {
        rewardsView.style.display = 'flex';
        codesView.style.display = 'none';
    });

    btnCodesView.addEventListener('click', () => {
        rewardsView.style.display = 'none';
        codesView.style.display = 'flex';
    });

    rewardsButton.addEventListener('click', () => {
        reward(partner, document.getElementById('rewardsPhone').value, apiKey, 1);
    });

    codesConsultButton.addEventListener('click', () => {
        consult(partner, document.getElementById('codesPhone').value, apiKey);
    });

    codesSendButton.addEventListener('click', () => {
        sendCode(partner, document.getElementById('codesPhone').value, apiKey);
    });

    codesRedeemButton.addEventListener('click', () => {
        redeem(partner, document.getElementById('codesPhone').value, document.getElementById('codesCode').value, apiKey, parseInt(document.getElementById('codesVisits').value));
    });

    // Show the modal
    document.body.classList.add('modal-open');
    modal.style.display = 'flex';

    // Ensure modal is cleaned up after being hidden
    modal.addEventListener('hidden.bs.modal', () => {
        modal.remove();
    });
}


function consult(partner, customer, apiKey) {
    if(customer.length < 7) {
        message('El número no es válido', 'red');
        return;
    }

    showLoader();

    var url = 'https://apig.systems:8000/rwc/get_phone_rewards_by_partner?id=' + partner.replace('+', '%2B');
    var body = { 'phone_id': customer }

    $.ajax({
        type: "POST",
        url: url,
        data: JSON.stringify(body),
        headers: {
            'rwc-id': apiKey,
            'Content-Type':'application/json'
        },
        success: function(data){
            hideLoader();
            console.log(data)
            if(data.status === 'error') message(data.message, 'red');
            else {
                var text = `El teléfono ${customer} tiene ${data.data.points} puntos en ${data.data.name}</br></br>`;

                if(data.data.prizes.length > 0) {
                    text += `<span style="font-weight: bold;">Promociones desbloqueadas:</span> </br>`;
                    data.data.prizes.forEach(e => {
                        text += `${e.name} (${e.quantity} puntos): ${e.prize} </br>`;
                    });
                    text += `</br>`;
                }

                if(data.data.prizes.length > 0) {
                    text += `<span style="font-weight: bold;">Historial:</span> </br>`;
                    data.history.forEach(e => {
                        text += `${e.type} (${e.quantity} puntos): ${e.date} </br>`;
                    });
                }
                message(text, 'black', "font-size: 18px;text-align: center;");
            }
        }
    });
}

function sendCode(partner, customer, apiKey) {
    if(customer.length < 7) {
        message('El número no es válido', 'red');
        return;
    }

    showLoader();

    var url = `https://apig.systems:8000/rwc/get_phone_code_secure?id=${customer.replace('+', '%2B')}&partner_id=${partner.replace('+', '%2B')}`;

    $.ajax({
        type: "GET",
        url: url,
        headers: { 'rwc-id': apiKey, 'Content-Type':'application/json' },
        success: function(data){
            hideLoader();
            console.log(data)
            if(data.status === 'error') message(data.message, 'red');
            else message(`Code sent`, 'green');
        }
    });
}

function getRewardsLeft(partner, apiKey) {
    var url = 'https://apig.systems:8000/rwc/get_rewards_left?id=' + partner.replace('+', '%2B');

    $.ajax({
        type: "GET",
        url: url,
        headers: {
            'rwc-id': apiKey,
            'Content-Type':'application/json'
        },
        success: function(data){
            console.log(data)
            if(data.status === 'error') message(data.message, 'red');
            else $('.modal-title').html(`${data.rewards} RwC`);
        }
    });
}

function reward(partner, customer, apiKey, rwc) {

    if(customer.length < 7) {
        message('El número no es válido', 'red');
        return;
    }

    showLoader();

    var url = 'https://apig.systems:8000/rwc/add_reward?id=' + partner.replace('+', '%2B');
    var body = {
        'phone_id': customer,
        'quantity': rwc
    }

    $.ajax({
        type: "POST",
        url: url,
        data: JSON.stringify(body),
        headers: {
            'rwc-id': apiKey,
            'Content-Type':'application/json'
        },
        success: function(data){
            hideLoader();
            console.log(data)
            if(data.status === 'error') message(data.message, 'red');
            else {
                message('Número registrado', 'green');
                $('#rewardsPhone').val('');
                getRewardsLeft(partner, apiKey);
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            hideLoader();
            message(`ERROR: ${XMLHttpRequest} ÑÑ ${errorThrown} ÑÑ ${textStatus}`, 'red');
        }
    });
}

function redeem(partner, customer, phoneCode, apiKey, rwc) {

    if(customer.length < 7) {
        message('El número no es válido', 'red');
        return;
    }

    showLoader();

    var url = 'https://apig.systems:8000/rwc/add_redeem?id=' + partner.replace('+', '%2B');
    var body = {
        'body': { reference: '' },
        'phone_id': customer,
        'code': phoneCode,
        'quantity': rwc
    }

    $.ajax({
        type: "POST",
        url: url,
        data: JSON.stringify(body),
        headers: {
            'rwc-id': apiKey,
            'Content-Type':'application/json'
        },
        success: function(data){
            hideLoader();
            console.log(data)
            if(data.status === 'error') message(data.message, 'red');
            else {
                message('Canjeo exitoso', 'green');
                $('#codesPhone').val('');
                $('#codesCode').val('');
                $('#codesVisits').val('');
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            hideLoader();
            message(`ERROR: ${XMLHttpRequest} ÑÑ ${errorThrown} ÑÑ ${textStatus}`, 'red');
        }
    });
}

function message(message, color, params = "text-align: center; font-size: 25px;") {
    const messageContainer = document.querySelector('.rwc-message');
    if (messageContainer) {
        messageContainer.innerHTML = `
            <div class="rwc-message" style="color: ${color};${params}">
                ${message}
            </div>
        `;
    }
}

function showLoader() {
    const loaderContainer = document.createElement('div');
    loaderContainer.className = 'rwc-loader-container';
    loaderContainer.innerHTML = '<div class="rwc-loader"></div>';
    document.body.appendChild(loaderContainer);
}


function hideLoader() {
    const loaderContainer = document.querySelector('.rwc-loader-container');
    if (loaderContainer) {
        loaderContainer.remove();
    }
}

function addCss() {
    console.log("ADD CSS");

    const style = document.createElement('style');
    style.textContent = `
        .rwc-btn-navbar {
            background-color: #72246c;
            color: #FFFFFF;
            border-color: #443b60;
        }

        .rwc-btn-navbar:hover {
            background-color: #4e174a;
            color: #FFFFFF;
            border-color: #443b60;
        }

        .rewards {
            background-color: #72246c;
            color: white;
            flex-grow: 1;
            border: solid 1px #bfbfbf;
            display: inline-block;
            line-height: 38px;
            min-width: 80px;
            text-align: center;
            border-radius: 3px;
            padding: 0px 10px;
            font-size: 18px;
            margin-left: 6px;
            margin-bottom: 6px;
            cursor: pointer;
            overflow: hidden;
            transition: all linear 150ms;
        }
        
        .rwc-btn {
            background-color: #72246c;
            border: none;
            color: white;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            transition-duration: 0.4s;
            cursor: pointer;
        }

        .rwc-btn-footer {
            background-color: #72246c;
            border: none;
            color: white;
            padding: 30px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            transition-duration: 0.4s;
            cursor: pointer;
        }
        
        .rwc-btn-footer:hover {
            background-color: #757575;
            color: white;
        }
          
        .rwc-btn:hover {
            background-color: #757575;
            color: white;
        }
          
        .rwc-loader-container {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background-color: #00000085;
            z-index: 10002;
        }

        .rwc-loader {
            position: absolute;
            margin: auto;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            border: 4px solid #f3f3f3;
            border-radius: 50%;
            border-top: 4px solid #72246c;
            width: 80px;
            height: 80px;
            -webkit-animation: rwc-spin 2s linear infinite; /* Safari */
            animation: rwc-spin 2s linear infinite;
        }

        /* Safari */
        @-webkit-keyframes rwc-spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
        }

        @keyframes rwc-spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);
}

addCss();