## Module <pos_button_visibility>

#### 12.03.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for User Wise Button Restrict In POS