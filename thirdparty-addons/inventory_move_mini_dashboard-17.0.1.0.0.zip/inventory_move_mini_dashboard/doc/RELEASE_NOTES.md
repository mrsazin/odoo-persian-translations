## Module <inventory_move_mini_dashboard>

#### 31.01.2024
#### Version 17.0.1.0.0
#### ADD
- Initial Commit for Inventory Move Mini Dashboard
