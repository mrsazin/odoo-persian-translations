Hide discuss
======================

Hide Discuss menu from user not in "Discuss user" group

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

