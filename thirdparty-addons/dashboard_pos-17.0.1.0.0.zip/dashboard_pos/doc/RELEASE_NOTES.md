## Module <pos_dashboard>

#### 28.11.2023
#### Version 17.0.1.0.0
##### ADD
-Initial Commit for POS Dashboard
