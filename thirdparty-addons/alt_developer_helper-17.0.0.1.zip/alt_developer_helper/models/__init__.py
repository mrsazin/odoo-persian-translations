# -*- coding: utf-8 -*-
from .import external_id_computer
from .import ir_filters
from .import ir_model_access
from .import ir_model
from .import ir_rule
from .import ir_sequence
from .import ir_ui_menu
from .import report_paperformat
from .import res_groups