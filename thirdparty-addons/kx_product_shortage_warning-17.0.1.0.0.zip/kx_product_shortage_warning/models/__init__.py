# -*- coding: utf-8 -*-
from . import product_product_inherit
from . import product_template_inherit
from . import pos_session_inherit
from . import res_config_settings_inherit
