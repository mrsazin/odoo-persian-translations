# -*- coding: utf-8 -*-
from odoo import api, fields, models


class ProductTemplateInherit(models.Model):
    _inherit = 'product.template'

    alert_condition = fields.Boolean(string='Product Warning State',
                                    compute='_compute_product_warning_state')
    background_color = fields.Char(string='Background color')

    @api.depends('qty_available')
    def _compute_product_warning_state(self):
        stock_alert = self.env['ir.config_parameter'].sudo().get_param(
            'kx_product_shortage_warning.has_low_stock_warning')
        for rec in self:
            if stock_alert:
                rec.alert_condition, rec.background_color = (False, 'white') if \
                    rec.detailed_type != 'product' or rec.qty_available > int(
                        rec.env['ir.config_parameter'].sudo().get_param(
                            'kx_product_shortage_warning.low_stock_trigger_value')) \
                    else (True, '#fdc6c673')
            else:
                rec.alert_condition = False
                rec.background_color = 'white'
