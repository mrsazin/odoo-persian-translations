# -*- coding: utf-8 -*-
from odoo import api, fields, models


class ProductProductInherit(models.Model):
    _inherit = 'product.product'

    product_warning_identifier = fields.Char(
        string='Product Warning identifier', compute='_compute_warning_tag')

    @api.depends('qty_available')
    def _compute_warning_tag(self):
        stock_alert = self.env['ir.config_parameter'].sudo().get_param(
            'kx_product_shortage_warning.has_low_stock_warning')
        for rec in self:
            if stock_alert:
                is_low_stock = True if rec.detailed_type == 'product' and rec.qty_available <= int(
                    self.env['ir.config_parameter'].sudo().get_param(
                        'kx_product_shortage_warning.low_stock_trigger_value')) else False
                rec.product_warning_identifier = rec.qty_available if is_low_stock else False
            else:
                rec.product_warning_identifier = False
