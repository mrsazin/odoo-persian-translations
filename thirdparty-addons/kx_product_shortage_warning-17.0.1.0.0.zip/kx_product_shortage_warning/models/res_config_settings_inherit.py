# -*- coding: utf-8 -*-
from odoo import fields, models


class ResConfigSettingsInherit(models.TransientModel):
    _inherit = 'res.config.settings'

    has_low_stock_warning = fields.Boolean(
        string="Low Stock Alert",
        help='Define the critical stock quantity that activates low stock alerts and adjusts product background colors.',
        config_parameter='kx_product_shortage_warning.has_low_stock_warning')
    low_stock_trigger_value = fields.Integer(
        string='Alert Quantity', default=0,
        help='Alter product background color to reflect stock levels determined by Warning quantity.',
        config_parameter='kx_product_shortage_warning.low_stock_trigger_value')
