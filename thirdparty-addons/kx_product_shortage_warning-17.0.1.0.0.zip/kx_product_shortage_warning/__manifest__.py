# -*- coding: utf-8 -*-
{
    'name': "Product Stock Shortage Warning",
    'summary': """Indicate low stock levels for products on both 
                point-of-sale screens and product detail pages.""",
    'description': """This module integrates Product Shortage Warning 
                    into the point of sale interface and product templates 
                    for improved stock management.""",

    'version': '17.0.1.0.0',
    "author": "KoderXpert Technologies LLP",
    "company": "KoderXpert Technologies LLP",
    "maintainer": "KoderXpert Technologies LLP",
    "website": "https://koderxpert.com",
    "category": 'Warehouse,Point of Sale',
    'depends': ['stock', 'point_of_sale'],
    'data': [
        'views/res_config_settings_views.xml',
        'views/product_product_views.xml',
        'views/product_template_views.xml'
    ],
    'assets': {
        'web.assets_backend': [
            'kx_product_shortage_warning/static/src/css/template_color.css',
        ],
        'point_of_sale._assets_pos': [
            'kx_product_shortage_warning/static/src/xml/product_item_template.xml',
            'kx_product_shortage_warning/static/src/xml/product_list_template.xml',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': "LGPL-3",
    'images': ['static/description/product_warning.gif'],
}
