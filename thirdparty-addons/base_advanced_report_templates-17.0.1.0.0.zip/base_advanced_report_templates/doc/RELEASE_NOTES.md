## Module <base_advanced_report_templates>

#### 09.04.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Odoo Professional Report Templates 
