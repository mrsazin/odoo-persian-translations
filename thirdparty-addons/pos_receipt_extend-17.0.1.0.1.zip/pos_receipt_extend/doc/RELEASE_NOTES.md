## Module <pos_receipt_extend>

#### 10.01.2024
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Advanced Pos Receipt

#### 16.04.2024
#### Version 17.0.1.0.1
#### BUGFIX
- Added superuser access to res.config.settings

