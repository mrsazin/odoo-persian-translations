Kitworks base mixins
=====================

Parts of date
--------------

Adds mixins Year, Day of week, Week, Month and Quarter


Extract date or datetime
----------------------------

Adds methods to extract date or datetime from strings, integer or datetime

Transliterate and clean
----------------------------

Adds methods to extract date or datetime from strings, integer or datetime

Transliterate by KMU rules
----------------------------

Adds methods to extract date or datetime from strings, integer or datetime

This module is developed by the `KitWorks <https://kitworks.systems/>`__.
