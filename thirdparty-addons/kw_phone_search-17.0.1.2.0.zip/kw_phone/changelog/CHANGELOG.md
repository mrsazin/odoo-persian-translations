# Changelog

## Version 1.2.0

- Remove unnecessary settings
- Refactoring end remove unnecessary inheritance


