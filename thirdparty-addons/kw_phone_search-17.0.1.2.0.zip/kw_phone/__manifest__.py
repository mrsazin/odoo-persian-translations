{
    'name': 'Phone number utility',

    'author': 'Kitworks Systems',
    'website': 'https://kitworks.systems/',

    'category': 'Extra Tools',
    'license': 'OPL-1',
    'version': '17.0.1.2.0',

    'depends': [
        'phone_validation', 'kw_mixin',
    ],
    'data': [
    ],
    'installable': True,

    'images': [
        'static/description/cover.png',
        'static/description/icon.png',
    ],
}
