Advanced contact search by name email and phone
===============================================

This module add advanced contact search by name email and phone

This module is developed by the `KitWorks <https://kitworks.systems/>`__.
