# Changelog

## Version 1.2.0

- Remove dependence from kw_phone_number_ua module
- Refactoring end remove unnecessary inheritance


