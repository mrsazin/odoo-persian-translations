## Module <pos_return_barcode>

#### 21.03.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for POS Return Barcode


#### 03.09.2024
#### Version 17.0.1.0.0
#### Bug Fix
- Updated the working that is patched ticket_screen and made changes in onClick() of return_product js