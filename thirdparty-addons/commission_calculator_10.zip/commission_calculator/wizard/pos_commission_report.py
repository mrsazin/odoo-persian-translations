from odoo import models, fields, api

class PosSaleReportUser(models.Model):
    _name = 'pos.sale.report.user'
    _description = 'POS Sale Report by User'
    _rec_name = 'display_name'

    user_id = fields.Many2one('res.users', string='User', required=True)
    date_from = fields.Date(string='Date From', required=True)
    date_to = fields.Date(string='Date To', required=True)
    sale_amount = fields.Float(string='Total Amount', compute='_compute_sale_amount', readonly=True)
    commission = fields.Float(string='Commission', compute='_compute_commission', readonly=True, help="Sale Amount * commission / 100")
    pos_order_ids = fields.One2many('pos.order', compute='_compute_pos_order_ids', string='POS Orders', readonly=True)
    commission_info = fields.Char(string='Commission Info', compute='_compute_commission_info')
    display_name = fields.Char(string='Display Name', compute='_compute_display_name')



    @api.depends('user_id', 'date_from', 'date_to')
    def _compute_sale_amount(self):
        for record in self:
            sales = self.env['pos.order'].search([
                ('user_id', '=', record.user_id.id),
                ('date_order', '>=', record.date_from),
                ('date_order', '<=', record.date_to),
                ('state', 'in', ['paid', 'done', 'invoiced', 'posted'])  # Adjust based on your POS order states
            ])
            record.sale_amount = sum(sale.amount_total for sale in sales)

    @api.depends('sale_amount')
    def _compute_commission(self):
        # for record in self:
        #     record.commission = record.sale_amount * 0.05
        for record in self:
            commission_rate = self.env['ir.config_parameter'].sudo().get_param('commission_calculator.commission_rate', default=0.5)
            record.commission = record.sale_amount * (float(commission_rate) / 100)
            

    @api.depends('user_id', 'date_from', 'date_to')
    def _compute_pos_order_ids(self):
        for record in self:
            sales = self.env['pos.order'].search([
                ('user_id', '=', record.user_id.id),
                ('date_order', '>=', record.date_from),
                ('date_order', '<=', record.date_to),
                ('state', 'in', ['paid', 'done', 'invoiced', 'posted'])  # Adjust based on your POS order states
            ])
            record.pos_order_ids = sales

    @api.depends('commission')
    def _compute_commission_info(self):
        for record in self:
            commission_rate = self.env['ir.config_parameter'].sudo().get_param('commission_calculator.commission_rate', default=0.5)
            record.commission_info = f"Current commission percentage is {commission_rate}%"

    @api.depends('user_id', 'date_from', 'date_to')
    def _compute_display_name(self):
        for record in self:
            if record.user_id and record.date_from and record.date_to:
                record.display_name = f"POS Commission Report for {record.user_id.name} from {record.date_from} to {record.date_to}"
            else:
                record.display_name = "POS Commission Report"

    def generate_report(self):
        self._compute_sale_amount()
        self._compute_commission()
        self._compute_pos_order_ids()
        self._compute_commission_info()
        self._compute_display_name()  

