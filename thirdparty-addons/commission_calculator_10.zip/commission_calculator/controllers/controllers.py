# -*- coding: utf-8 -*-
# from odoo import http


# class CommissionCalculator(http.Controller):
#     @http.route('/commission_calculator/commission_calculator', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/commission_calculator/commission_calculator/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('commission_calculator.listing', {
#             'root': '/commission_calculator/commission_calculator',
#             'objects': http.request.env['commission_calculator.commission_calculator'].search([]),
#         })

#     @http.route('/commission_calculator/commission_calculator/objects/<model("commission_calculator.commission_calculator"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('commission_calculator.object', {
#             'object': obj
#         })

