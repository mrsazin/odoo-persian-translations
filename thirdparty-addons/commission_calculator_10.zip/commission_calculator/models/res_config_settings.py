# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo import http
from odoo.http import request
    

class ResConfig(models.TransientModel):
    """
    This is an Odoo model for configuration settings. It inherits from the
    'res.config.settings' model and extends its functionality by adding
    fields for low stock alert configuration

    """
    _inherit = 'res.config.settings'

    commission_rate = fields.Float (
        string="Commission Rate",
        config_parameter='commission_calculator.commission_rate',
        default=0.5
    )
