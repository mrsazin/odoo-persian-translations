## Module <pos_custom_percentage_tip_fixed>

#### 18.03.2023
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Pos Custom Tips 
