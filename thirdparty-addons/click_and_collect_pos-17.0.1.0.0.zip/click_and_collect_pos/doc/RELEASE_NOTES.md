## Module <click_and_collect_pos>

#### 01.02.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Click and Collect POS
