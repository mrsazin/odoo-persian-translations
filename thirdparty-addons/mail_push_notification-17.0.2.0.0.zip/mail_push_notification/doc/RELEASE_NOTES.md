## Module <mail_push_notification>

#### 01.12.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Push Notification From ChatBox

#### 01.06.2024
#### Version 17.0.2.0.0
#### UPDT
- Migrated from legacy FCM APIs to HTTP v1