# -*- coding: utf-8 -*-

from . import pos_session
from . import product_product
from . import res_config_settings
from . import stock_quant
