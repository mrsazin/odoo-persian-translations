from odoo import http
from odoo.http import request
from odoo import models

class MyController(http.Controller):
    
    @http.route(['/nthub_low_stock_managment/get_setting'], type='json', auth="user", website=True)
    def get_setting(self, *args, **kw):
        my_setting = request.env['ir.config_parameter'].sudo().get_param('nthub_low_stock_management.is_auto_refresh')
        return my_setting
    
    @http.route(['/nthub_low_stock_managment/get_refresh_interval'], type='json', auth="user", website=True)
    def get_refresh_interval(self, *args, **kw):
        my_setting = request.env['ir.config_parameter'].sudo().get_param('nthub_low_stock_management.refresh_interval')
        return my_setting
    
    @http.route(['/nthub_low_stock_managment/get_menu_info'], type='json', auth="user", website=True)
    def get_menu_info(self, menu_id):
        menu = request.env['ir.ui.menu'].browse(menu_id)
        if menu.exists():
            return {
                'id': menu.id,
                'name': menu.name,
                'parent_id': menu.parent_id.id,
                'complete_name': menu.complete_name,
            }
        else:
            return {'error': 'Menu not found'}   

