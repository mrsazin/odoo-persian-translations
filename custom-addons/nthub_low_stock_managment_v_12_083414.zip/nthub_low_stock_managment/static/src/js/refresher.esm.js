/** @odoo-module **/
/* Copyright 2022 Tecnativa - Alexandre D. Díaz
 * Copyright 2022 Tecnativa - Carlos Roca
 * Copyright 2023 Taras Shabaranskyi
 * License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl). */
 
import {Component, onMounted, onWillUnmount} from "@odoo/owl";
import {useDebounced} from "@web/core/utils/timing";
import { useService } from "@web/core/utils/hooks"; 


export function useRefreshAnimation(timeout) {
    const refreshClass = "o_content__refresh";
    let timeoutId = null;

    /**
     * @returns {DOMTokenList|null}
     */
    function contentClassList() {
        const content = document.querySelector(".o_content");
        return content ? content.classList : null;
    }

    function clearAnimationTimeout() {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
        timeoutId = null;
    }

    function animate() {
        clearAnimationTimeout();
        contentClassList().add(refreshClass);
        timeoutId = setTimeout(() => {
            contentClassList().remove(refreshClass);
            clearAnimationTimeout();
        }, timeout);
    }

    return animate;
}

export class Refresher extends Component {
    timeout_id = null
    is_done = false
    refresh_interval = 60000

    setup() {
        super.setup();
        this.rpc = useService('rpc');
        this.refreshAnimation = useRefreshAnimation(1000);
        this.onClickRefresh = useDebounced(this.onClickRefresh, 200);                

        onMounted(() => {
            this.isAutoRefresh();
        });
        onWillUnmount(() => {
            clearTimeout(this.timeout_id);
        });
    }

    async isAutoRefresh(self) {
        debugger;
        const result = await this.rpc('/nthub_low_stock_managment/get_setting');
        if (result == 'True'){
            const is_correct_menu = await this.isCorrectMenu();
            if (this && is_correct_menu){
                debugger;
                this.refresh_interval = await this.rpc('/nthub_low_stock_managment/get_refresh_interval');
                if (this.refresh_interval == false)
                    this.refresh_interval = 60000;
                this.timeout_id = setTimeout(this.onClickRefresh, Number(this.refresh_interval));
            }
        }
    }

    async isCorrectMenu(self) {
        const currentURL = window.location.href;
        const urlObj = new URL(currentURL);
        const fragment = urlObj.hash.substring(1); // حذف علامت #
        const params = new URLSearchParams(fragment);
        const menu_id = params.get('menu_id');

        if (!menu_id)
            return false;
        const result = await this.rpc('/nthub_low_stock_managment/get_menu_info', {menu_id: Number(menu_id)});
        if (result.name == "Stock Quantity Online")
            return true;
        else
            return false;
    }

    /**
     * @returns {Boolean}
     */
    get displayButton() {
        return (async ()=> {
            const {searchModel, pagerProps} = this.props;
            const hasSearchModel = searchModel && searchModel.search;
            this.is_done = await this.isCorrectMenu();
            console.log(this.is_done);
            if (this.is_done == true)
                return true;
            else
                return false;
        })();
    }

    /**
     * @returns {Boolean}
     * @private
     */
    _searchModelRefresh() {
        const {searchModel} = this.props;
        if (searchModel && typeof searchModel.search === "function") {
            searchModel.search();
            return true;
        }
        return false;
    }

    /**
     * @returns {Promise<Boolean>}
     * @private
     */
    async _pagerRefresh() {
        const pagerProps = this.props.pagerProps;
        if (pagerProps && typeof pagerProps.onUpdate === "function") {
            const {limit, offset} = pagerProps;
            await pagerProps.onUpdate({offset, limit});
            return true;
        }
        return false;
    }

    /**
     * @returns {Promise<Boolean>}
     */
    async refresh() {
        let updated = this._searchModelRefresh();
        if (!updated) {
            updated = await this._pagerRefresh();
        }
        return updated;
    }

    async onClickRefresh() {
        const updated = await this.refresh();
        if (updated) {
            this.refreshAnimation();
            if (this.timeout_id)
                clearTimeout(this.timeout_id);
            debugger;
            this.timeout_id = setTimeout(this.onClickRefresh, Number(this.refresh_interval));
        }

        
    }    
}

Object.assign(Refresher, {
    template: "web_refresher.Button",
    props: {
        searchModel: {type: Object, optional: true},
        pagerProps: {type: Object, optional: true},
    },
});

