# -*- coding: utf-8 -*-
# from odoo import http


# class FadooPersianCalendar(http.Controller):
#     @http.route('/fadoo_calendar/fadoo_calendar', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/fadoo_calendar/fadoo_calendar/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('fadoo_calendar.listing', {
#             'root': '/fadoo_calendar/fadoo_calendar',
#             'objects': http.request.env['fadoo_calendar.fadoo_calendar'].search([]),
#         })

#     @http.route('/fadoo_calendar/fadoo_calendar/objects/<model("fadoo_calendar.fadoo_calendar"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('fadoo_calendar.object', {
#             'object': obj
#         })
