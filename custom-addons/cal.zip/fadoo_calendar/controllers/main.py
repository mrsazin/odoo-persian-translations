# -*- coding: utf-8 -*-
import datetime
import io

import jdatetime

from odoo import _
from odoo.addons.web.controllers.export import CSVExport, ExcelExport
from odoo.http import request
from odoo.tools import (DEFAULT_SERVER_DATE_FORMAT,
                        DEFAULT_SERVER_DATETIME_FORMAT, pycompat)


class CSVExportInherit(CSVExport):

    def from_data(self, fields, rows):
        if request.env.user.lang == 'fa_IR':
            fp = io.BytesIO()
            writer = pycompat.csv_writer(fp, quoting=1)
            writer.writerow(fields)
            for data in rows:
                row = []
                for d in data:
                    # Spreadsheet apps tend to detect formulas on leading =, + and -
                    if isinstance(d, str) and d.startswith(('=', '-', '+')):
                        d = "'" + d
                    ########## Overrided ##########
                    elif isinstance(d, datetime.datetime):
                        d = jdatetime.datetime.fromgregorian(datetime=d).strftime(DEFAULT_SERVER_DATETIME_FORMAT)
                    elif isinstance(d, datetime.date):
                        d = jdatetime.datetime.fromgregorian(date=d).strftime(DEFAULT_SERVER_DATE_FORMAT)
                    ########## ######### ##########
                    row.append(pycompat.to_text(d))
                writer.writerow(row)

            return fp.getvalue()
        else:
            return super().from_data(fields, rows)


class ExcelExportInherit(ExcelExport):

    def from_group_data(self, fields, groups):
        if request.env.user.lang == 'fa_IR':
            for group_name, group in groups.children.items():
                for data in group.data:
                    for i in range(len(data)):
                        if isinstance(data[i], datetime.datetime):
                            data[i] = jdatetime.datetime.fromgregorian(datetime=data[i]).strftime(DEFAULT_SERVER_DATETIME_FORMAT)
                        elif isinstance(data[i], datetime.date):
                            data[i] = jdatetime.datetime.fromgregorian(date=data[i]).strftime(DEFAULT_SERVER_DATE_FORMAT)
        return super().from_group_data(fields, groups)


    def from_data(self, fields, rows):
        if request.env.user.lang == 'fa_IR':
            for data in rows:
                for i in range(len(data)):
                    if isinstance(data[i], datetime.datetime):
                        data[i] = jdatetime.datetime.fromgregorian(datetime=data[i]).strftime(DEFAULT_SERVER_DATETIME_FORMAT)
                    elif isinstance(data[i], datetime.date):
                        data[i] = jdatetime.datetime.fromgregorian(date=data[i]).strftime(DEFAULT_SERVER_DATE_FORMAT)
        return super().from_data(fields, rows)