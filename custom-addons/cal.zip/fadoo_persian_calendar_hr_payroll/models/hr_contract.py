import itertools
from collections import defaultdict
from datetime import date, datetime, time
from itertools import chain

import pytz
from dateutil.relativedelta import relativedelta
from dateutil.rrule import DAILY, rrule
from odoo import _, api, fields, models
from odoo.addons.hr_work_entry_contract.models.hr_work_intervals import \
    WorkIntervals
from odoo.addons.resource.models.resource import (Intervals,
                                                  datetime_to_string,
                                                  float_to_time, make_aware,
                                                  string_to_datetime)
from odoo.exceptions import UserError
from odoo.osv import expression
from pytz import timezone, utc


def my_make_aware(dt):
    if dt.tzinfo:
        return dt, lambda val: val
    else:
        return dt.replace(tzinfo=utc), lambda val: val
make_aware = my_make_aware

def my_string_to_datetime(value):
    return fields.Datetime.from_string(value)
string_to_datetime = my_string_to_datetime

def my_datetime_to_string(dt):
    return fields.Datetime.to_string(dt)
datetime_to_string = my_datetime_to_string

class HrContract(models.Model):
    _inherit = 'hr.contract'
    
    def _get_attendance_intervals(self, start_dt, end_dt):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_attendance_intervals(start_dt, end_dt)
        
        employees_by_calendar = defaultdict(lambda: self.env['hr.employee'])
        for contract in self:
            employees_by_calendar[contract.resource_calendar_id] |= contract.employee_id
        result = dict()
        for calendar, employees in employees_by_calendar.items():
            result.update(calendar._attendance_intervals_batch(
                start_dt,
                end_dt,
                resources=employees.resource_id
            ))
        return result
    
    def _get_interval_leave_work_entry_type(self, interval, leaves, bypassing_codes):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_interval_leave_work_entry_type(interval, leaves, bypassing_codes)
        self.ensure_one()
        for leave in leaves:
            if interval[0] >= leave[0] and interval[1] <= leave[1] and leave[2]:
                interval_start = interval[0]
                interval_stop = interval[1]
                return self._get_leave_work_entry_type_dates(leave[2], interval_start, interval_stop, self.employee_id)
        return self.env.ref('hr_work_entry_contract.work_entry_type_leave')
    
    def _get_contract_credit_time_values(self, date_start, date_stop):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_contract_credit_time_values(date_start, date_stop)
        
        contract_vals = []
        for contract in self:
            if not contract.time_credit or not contract.time_credit_type_id:
                continue

            employee = contract.employee_id
            resource = employee.resource_id
            calendar = contract.resource_calendar_id
            standard_calendar = contract.standard_calendar_id

            # YTI TODO master: The domain is hacky, but we can't modify the method signature
            # Add an argument compute_leaves=True on the method
            standard_attendances = standard_calendar._work_intervals_batch(date_start,date_stop,
                resources=resource,
                domain=[('resource_id', '=', -1)])[resource.id]

            # YTI TODO master: The domain is hacky, but we can't modify the method signature
            # Add an argument compute_leaves=True on the method
            attendances = calendar._work_intervals_batch(date_start,date_stop,
                resources=resource,
                domain=[('resource_id', '=', -1)]
            )[resource.id]

            credit_time_intervals = standard_attendances - attendances

            for interval in credit_time_intervals:
                work_entry_type_id = contract.time_credit_type_id
                contract_vals += [{
                    'name': "%s: %s" % (work_entry_type_id.name, employee.name),
                    'date_start': interval[0],
                    'date_stop': interval[1],
                    'work_entry_type_id': work_entry_type_id.id,
                    'employee_id': employee.id,
                    'contract_id': contract.id,
                    'company_id': contract.company_id.id,
                    'state': 'draft',
                }]
        return contract_vals
    
    def _get_work_hours(self, date_from, date_to, domain=None):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_work_hours(date_from, date_to, domain=None)
     
        date_from = datetime.combine(date_from, datetime.min.time())
        date_to = datetime.combine(date_to, datetime.max.time())
        date_from = date_from
        date_to = date_to
        work_data = defaultdict(int)

        # First, found work entry that didn't exceed interval.
        work_entries = self.env['hr.work.entry']._read_group(
            self._get_work_hours_domain(date_from, date_to, domain=domain, inside=True),
            ['hours:sum(duration)'],
            ['work_entry_type_id']
        )
        work_data.update({data['work_entry_type_id'][0] if data['work_entry_type_id'] else False: data['hours'] for data in work_entries})
        self._preprocess_work_hours_data(work_data, date_from, date_to)

        # Second, find work entry that exceeds interval and compute right duration.
        work_entries = self.env['hr.work.entry'].search(self._get_work_hours_domain(date_from, date_to, domain=domain, inside=False))

        for work_entry in work_entries:
            date_start = max(date_from, work_entry.date_start)
            date_stop = min(date_to, work_entry.date_stop)
            if work_entry.work_entry_type_id.is_leave:
                contract = work_entry.contract_id
                calendar = contract.resource_calendar_id
                employee = contract.employee_id
                contract_data = employee._get_work_days_data_batch(
                    date_start, date_stop, compute_leaves=False, calendar=calendar
                )[employee.id]

                work_data[work_entry.work_entry_type_id.id] += contract_data.get('hours', 0)
            else:
                work_data[work_entry.work_entry_type_id.id] += work_entry._get_work_duration(date_start, date_stop)  # Number of hours
        return work_data
    
    def _get_contract_work_entries_values(self, date_start, date_stop):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_contract_work_entries_values(date_start, date_stop)
        
        start_dt = date_start
        end_dt =  date_stop

        contract_vals = []
        bypassing_work_entry_type_codes = self._get_bypassing_work_entry_type_codes()

        attendances_by_resource = self._get_attendance_intervals(start_dt, end_dt)

        resource_calendar_leaves = self.env['resource.calendar.leaves'].search(self._get_leave_domain(start_dt, end_dt))
        # {resource: resource_calendar_leaves}
        leaves_by_resource = defaultdict(lambda: self.env['resource.calendar.leaves'])
        for leave in resource_calendar_leaves:
            leaves_by_resource[leave.resource_id.id] |= leave

        tz_dates = {}
        for contract in self:
            employee = contract.employee_id
            calendar = contract.resource_calendar_id
            resource = employee.resource_id
            tz = pytz.timezone(calendar.tz)

            attendances = attendances_by_resource[resource.id]

            # Other calendars: In case the employee has declared time off in another calendar
            # Example: Take a time off, then a credit time.
            # YTI TODO: This mimics the behavior of _leave_intervals_batch, while waiting to be cleaned
            # in master.
            resources_list = [self.env['resource.resource'], resource]
            result = defaultdict(lambda: [])
            for leave in itertools.chain(leaves_by_resource[False], leaves_by_resource[resource.id]):
                for resource in resources_list:
                    # Global time off is not for this calendar, can happen with multiple calendars in self
                    if resource and leave.calendar_id and leave.calendar_id != calendar and not leave.resource_id:
                        continue
                    tz = tz if tz else pytz.timezone((resource or contract).tz)
                    if (tz, start_dt) in tz_dates:
                        start = tz_dates[(tz, start_dt)]
                    else:
                        start = start_dt
                        tz_dates[(tz, start_dt)] = start
                    if (tz, end_dt) in tz_dates:
                        end = tz_dates[(tz, end_dt)]
                    else:
                        end = end_dt
                        tz_dates[(tz, end_dt)] = end
                    dt0 = string_to_datetime(leave.date_from)
                    dt1 = string_to_datetime(leave.date_to)
                    result[resource.id].append((max(start, dt0), min(end, dt1), leave))
            mapped_leaves = {r.id: Intervals(result[r.id]) for r in resources_list}
            leaves = mapped_leaves[resource.id]

            real_attendances = attendances - leaves
            if contract.has_static_work_entries() or not leaves:
                # Empty leaves means empty real_leaves
                real_leaves = attendances - real_attendances
            else:
                # In the case of attendance based contracts use regular attendances to generate leave intervals
                static_attendances = calendar._attendance_intervals_batch(
                    start_dt, end_dt, resources=resource, tz=tz)[resource.id]
                real_leaves = static_attendances & leaves

            if not contract.has_static_work_entries():
                # An attendance based contract might have an invalid planning, by definition it may not happen with
                # static work entries.
                # Creating overlapping slots for example might lead to a single work entry.
                # In that case we still create both work entries to indicate a problem (conflicting W E).
                split_attendances = []
                for attendance in real_attendances:
                    if attendance[2] and len(attendance[2]) > 1:
                        split_attendances += [(attendance[0], attendance[1], a) for a in attendance[2]]
                    else:
                        split_attendances += [attendance]
                real_attendances = split_attendances

            # A leave period can be linked to several resource.calendar.leave
            split_leaves = []
            for leave_interval in leaves:
                if leave_interval[2] and len(leave_interval[2]) > 1:
                    split_leaves += [(leave_interval[0], leave_interval[1], l) for l in leave_interval[2]]
                else:
                    split_leaves += [(leave_interval[0], leave_interval[1], leave_interval[2])]
            leaves = split_leaves

            # Attendances
            default_work_entry_type = contract._get_default_work_entry_type()
            for interval in real_attendances:
                work_entry_type = 'work_entry_type_id' in interval[2] and interval[2].work_entry_type_id[:1]\
                    or default_work_entry_type
                # All benefits generated here are using datetimes converted from the employee's timezone
                contract_vals += [dict([
                    ('name', "%s: %s" % (work_entry_type.name, employee.name)),
                    ('date_start', interval[0]),
                    ('date_stop', interval[1]),
                    ('work_entry_type_id', work_entry_type.id),
                    ('employee_id', employee.id),
                    ('contract_id', contract.id),
                    ('company_id', contract.company_id.id),
                    ('state', 'draft'),
                ] + contract._get_more_vals_attendance_interval(interval))]

            for interval in real_leaves:
                # Could happen when a leave is configured on the interface on a day for which the
                # employee is not supposed to work, i.e. no attendance_ids on the calendar.
                # In that case, do try to generate an empty work entry, as this would raise a
                # sql constraint error
                if interval[0] == interval[1]:  # if start == stop
                    continue
                leave_entry_type = contract._get_interval_leave_work_entry_type(interval, leaves, bypassing_work_entry_type_codes)
                interval_leaves = [leave for leave in leaves if leave[2].work_entry_type_id.id == leave_entry_type.id]
                interval_start = interval[0]
                interval_stop = interval[1]
                contract_vals += [dict([
                    ('name', "%s%s" % (leave_entry_type.name + ": " if leave_entry_type else "", employee.name)),
                    ('date_start', interval_start),
                    ('date_stop', interval_stop),
                    ('work_entry_type_id', leave_entry_type.id),
                    ('employee_id', employee.id),
                    ('company_id', contract.company_id.id),
                    ('state', 'draft'),
                    ('contract_id', contract.id),
                ] + contract._get_more_vals_leave_interval(interval, interval_leaves))]
        return contract_vals
    
    def _get_attendance_intervals(self, start_dt, end_dt):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_attendance_intervals(start_dt, end_dt)
        
        planning_based_contracts = self.filtered(lambda c: c.work_entry_source == 'planning')
        search_domain = [
            ('employee_id', 'in', planning_based_contracts.employee_id.ids),
            ('state', '=', 'published'),
            ('start_datetime', '<', end_dt),
            ('end_datetime', '>', start_dt),
        ]
        resource_ids = planning_based_contracts.employee_id.resource_id.ids
        planning_slots = self.env['planning.slot'].sudo().search(search_domain) if planning_based_contracts\
            else self.env['planning.slot']
        intervals = defaultdict(list)
        for planning_slot in planning_slots:
            intervals[planning_slot.resource_id.id].append((
                max(start_dt, planning_slot.start_datetime),
                min(end_dt, planning_slot.end_datetime),
                planning_slot))
        mapped_intervals = {r: WorkIntervals(intervals[r]) for r in resource_ids}
        mapped_intervals.update(super(HrContract, self - planning_based_contracts)._get_attendance_intervals(start_dt, end_dt))
        return mapped_intervals
    
    def _generate_work_entries(self, date_start, date_stop, force=False):
        if not self.env.user.lang == 'fa_IR':
            return super()._generate_work_entries(date_start, date_stop, force=False)
        
        self = self.with_context(tracking_disable=True)
        canceled_contracts = self.filtered(lambda c: c.state == 'cancel')
        if canceled_contracts:
            raise UserError(
                _("Sorry, generating work entries from cancelled contracts is not allowed.") + '\n%s' % (
                    ', '.join(canceled_contracts.mapped('name'))))
        vals_list = []
        date_start = fields.Datetime.to_datetime(date_start)
        date_stop = datetime.combine(fields.Datetime.to_datetime(date_stop), datetime.max.time())
        self.write({'last_generation_date': fields.Date.today()})

        intervals_to_generate = defaultdict(lambda: self.env['hr.contract'])
        # In case the date_generated_from == date_generated_to, move it to the date_start to
        # avoid trying to generate several months/years of history for old contracts for which
        # we've never generated the work entries.
        self.filtered(lambda c: c.date_generated_from == c.date_generated_to).write({
            'date_generated_from': date_start,
            'date_generated_to': date_start,
        })
        for contract in self:
            contract_start = fields.Datetime.to_datetime(contract.date_start)
            contract_stop = datetime.combine(fields.Datetime.to_datetime(contract.date_end or datetime.max.date()),
                                             datetime.max.time())
            if date_start > contract_stop or date_stop < contract_start:
                continue
            date_start_work_entries = max(date_start, contract_start)
            date_stop_work_entries = min(date_stop, contract_stop)
            if force:
                intervals_to_generate[(date_start_work_entries, date_stop_work_entries)] |= contract
                continue

            # For each contract, we found each interval we must generate
            # In some cases we do not want to set the generated dates beforehand, since attendance based work entries
            #  is more dynamic, we want to update the dates within the _get_work_entries_values function
            is_static_work_entries = contract.has_static_work_entries()
            last_generated_from = min(contract.date_generated_from, contract_stop)
            if last_generated_from > date_start_work_entries:
                if is_static_work_entries:
                    contract.date_generated_from = date_start_work_entries
                intervals_to_generate[(date_start_work_entries, last_generated_from)] |= contract

            last_generated_to = max(contract.date_generated_to, contract_start)
            if last_generated_to < date_stop_work_entries:
                if is_static_work_entries:
                    contract.date_generated_to = date_stop_work_entries
                intervals_to_generate[(last_generated_to, date_stop_work_entries)] |= contract

        for interval, contracts in intervals_to_generate.items():
            date_from, date_to = interval
            # timezones = contracts.resource_calendar_id.mapped('tz')
            vals_list.extend(contracts._get_work_entries_values(date_from, date_to))
            # for timezone in timezones:
            #     tz = pytz.timezone(timezone)
            #     date_from = tz.localize(date_from) if not date_from.tzinfo else date_from
            #     date_to = tz.localize(date_to) if not date_to.tzinfo else date_to
            #     vals_list.extend(contracts.filtered(lambda c: c.resource_calendar_id.tz == timezone)._get_work_entries_values(date_from, date_to))

        if not vals_list:
            return self.env['hr.work.entry']

        return self.env['hr.work.entry'].create(vals_list)

class HrPayslipEmployees(models.TransientModel):
    _inherit = 'hr.payslip.employees'
    
    def _check_undefined_slots(self, work_entries, payslip_run):
        if not self.env.user.lang == 'fa_IR':
            return super()._check_undefined_slots(work_entries, payslip_run)
        
        work_entries_by_contract = defaultdict(lambda: self.env['hr.work.entry'])
        for work_entry in work_entries:
            work_entries_by_contract[work_entry.contract_id] |= work_entry

        for contract, work_entries in work_entries_by_contract.items():
            if contract.work_entry_source != 'calendar':
                continue
            calendar_start = datetime.combine(max(contract.date_start, payslip_run.date_start), time.min)
            calendar_end = datetime.combine(min(contract.date_end or date.max, payslip_run.date_end), time.max)
            outside = contract.resource_calendar_id._attendance_intervals_batch(calendar_start, calendar_end)[False] - work_entries._to_intervals()
            if outside:
                time_intervals_str = "\n - ".join(['', *["%s -> %s" % (s[0], s[1]) for s in outside._items]])
                raise UserError(_("Some part of %s's calendar is not covered by any work entry. Please complete the schedule. Time intervals to look for:%s") % (contract.employee_id.name, time_intervals_str))
            

class ResourceCalendar(models.Model):

    _inherit = "resource.calendar"
    
    @api.depends('tz')
    def _compute_tz_offset(self):
        if not self.env.user.lang == 'fa_IR':
            return super()._compute_tz_offset()
        for calendar in self:
            calendar.tz_offset = datetime.now().strftime('%z')
            
            
    def _attendance_intervals_batch(self, start_dt, end_dt, resources=None, domain=None, tz=None):
        if not self.env.user.lang == 'fa_IR':
            return super()._attendance_intervals_batch(start_dt, end_dt, resources=None, domain=None, tz=None)
        
        self.ensure_one()

        if not resources:
            resources = self.env['resource.resource']
            resources_list = [resources]
        else:
            resources_list = list(resources) + [self.env['resource.resource']]
        resource_ids = [r.id for r in resources_list]
        domain = domain if domain is not None else []
        domain = expression.AND([domain, [
            ('calendar_id', '=', self.id),
            ('resource_id', 'in', resource_ids),
            ('display_type', '=', False),
        ]])

        attendances = self.env['resource.calendar.attendance'].search(domain)
        # Since we only have one calendar to take in account
        # Group resources per tz they will all have the same result
        resources_per_tz = defaultdict(list)
        for resource in resources_list:
            resources_per_tz[tz].append(resource)
        # Resource specific attendances
        attendance_per_resource = defaultdict(lambda: self.env['resource.calendar.attendance'])
        # Calendar attendances per day of the week
        # * 7 days per week * 2 for two week calendars
        attendances_per_day = [self.env['resource.calendar.attendance']] * 7 * 2
        weekdays = set()
        for attendance in attendances:
            if attendance.resource_id:
                attendance_per_resource[attendance.resource_id] |= attendance
            weekday = int(attendance.dayofweek)
            weekdays.add(weekday)
            if self.two_weeks_calendar:
                weektype = int(attendance.week_type)
                attendances_per_day[weekday + 7 * weektype] |= attendance
            else:
                attendances_per_day[weekday] |= attendance
                attendances_per_day[weekday + 7] |= attendance

        start = start_dt
        end = end_dt
        bounds_per_tz = {
            tz: (start_dt, end_dt)
            for tz in resources_per_tz.keys()
        }
        # Use the outer bounds from the requested timezones
        for tz, bounds in bounds_per_tz.items():
            start = min(start, bounds[0])
            end = max(end, bounds[1])
        # Generate once with utc as timezone
        days = rrule(DAILY, start.date(), until=end.date(), byweekday=weekdays)
        ResourceCalendarAttendance = self.env['resource.calendar.attendance']
        base_result = []
        per_resource_result = defaultdict(list)
        for day in days:
            week_type = ResourceCalendarAttendance.get_week_type(day)
            attendances = attendances_per_day[day.weekday() + 7 * week_type]
            for attendance in attendances:
                if (attendance.date_from and day.date() < attendance.date_from) or\
                    (attendance.date_to and attendance.date_to < day.date()):
                    continue
                day_from = datetime.combine(day, float_to_time(attendance.hour_from))
                day_to = datetime.combine(day, float_to_time(attendance.hour_to))
                if attendance.resource_id:
                    per_resource_result[attendance.resource_id].append((day_from, day_to, attendance))
                else:
                    base_result.append((day_from, day_to, attendance))

        # Copy the result localized once per necessary timezone
        # Strictly speaking comparing start_dt < time or start_dt.astimezone(tz) < time
        # should always yield the same result. however while working with dates it is easier
        # if all dates have the same format
        result_per_tz = {
            tz: [(max(bounds_per_tz[tz][0].replace(tzinfo=None), val[0].replace(tzinfo=None)),
                min(bounds_per_tz[tz][1].replace(tzinfo=None), val[1].replace(tzinfo=None)),
                val[2])
                    for val in base_result]
            for tz in resources_per_tz.keys()
        }
        result_per_resource_id = dict()
        for tz, resources in resources_per_tz.items():
            res = result_per_tz[tz]
            res_intervals = Intervals(res)
            for resource in resources:
                if resource in per_resource_result:
                    resource_specific_result = [(max(bounds_per_tz[tz][0], val[0]), min(bounds_per_tz[tz][1], val[1]), val[2])
                        for val in per_resource_result[resource]]
                    result_per_resource_id[resource.id] = Intervals(itertools.chain(res, resource_specific_result))
                else:
                    result_per_resource_id[resource.id] = res_intervals
        return result_per_resource_id
    
    def _leave_intervals_batch(self, start_dt, end_dt, resources=None, domain=None, tz=None, any_calendar=False):
        if not self.env.user.lang == 'fa_IR':
            return super()._leave_intervals_batch(start_dt, end_dt, resources=None, domain=None, tz=None, any_calendar=False)
        
        # assert start_dt.tzinfo and end_dt.tzinfo
        self.ensure_one()

        if not resources:
            resources = self.env['resource.resource']
            resources_list = [resources]
        else:
            resources_list = list(resources) + [self.env['resource.resource']]
        resource_ids = [r.id for r in resources_list]
        if domain is None:
            domain = [('time_type', '=', 'leave')]
        if not any_calendar:
            domain = domain + [('calendar_id', 'in', [False, self.id])]
        # for the computation, express all datetimes in UTC
        domain = domain + [
            ('resource_id', 'in', resource_ids),
            ('date_from', '<=', datetime_to_string(end_dt)),
            ('date_to', '>=', datetime_to_string(start_dt)),
        ]

        # retrieve leave intervals in (start_dt, end_dt)
        result = defaultdict(lambda: [])
        # tz_dates = {}
        for leave in self.env['resource.calendar.leaves'].search(domain):
            for resource in resources_list:
                if leave.resource_id.id not in [False, resource.id]:
                    continue
                # tz = tz if tz else timezone((resource or self).tz)
                # if (tz, start_dt) in tz_dates:
                #     start = tz_dates[(tz, start_dt)]
                # else:
                #     start = start_dt
                #     tz_dates[(tz, start_dt)] = start
                # if (tz, end_dt) in tz_dates:
                #     end = tz_dates[(tz, end_dt)]
                # else:
                #     end = end_dt
                #     tz_dates[(tz, end_dt)] = end
                start = start_dt.replace(tzinfo=None)
                end = end_dt.replace(tzinfo=None)
                dt0 = string_to_datetime(leave.date_from).replace(tzinfo=None)
                dt1 = string_to_datetime(leave.date_to).replace(tzinfo=None)
                result[resource.id].append((max(start, dt0), min(end, dt1), leave))

        return {r.id: Intervals(result[r.id]) for r in resources_list}
    
    def _unavailable_intervals_batch(self, start_dt, end_dt, resources=None, domain=None, tz=None):
        if not self.env.user.lang == 'fa_IR':
            return super()._unavailable_intervals_batch(start_dt, end_dt, resources=None, domain=None, tz=None)
        if not resources:
            resources = self.env['resource.resource']
            resources_list = [resources]
        else:
            resources_list = list(resources)

        resources_work_intervals = self._work_intervals_batch(start_dt, end_dt, resources, domain, tz)
        result = {}
        for resource in resources_list:
            work_intervals = [(start, stop) for start, stop, meta in resources_work_intervals[resource.id]]
            # start + flatten(intervals) + end
            work_intervals = [start_dt] + list(chain.from_iterable(work_intervals)) + [end_dt]
            # put it back to UTC
            work_intervals = list(map(lambda dt: dt, work_intervals))
            # pick groups of two
            work_intervals = list(zip(work_intervals[0::2], work_intervals[1::2]))
            result[resource.id] = work_intervals
        return result
    
    def _get_closest_work_time(self, dt, match_end=False, resource=None, search_range=None, compute_leaves=True):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_closest_work_time(dt, match_end=False, resource=None, search_range=None, compute_leaves=True)
        
        def interval_dt(interval):
            return interval[1 if match_end else 0]

        tz = resource.tz if resource else self.tz
        if resource is None:
            resource = self.env['resource.resource']

        if not dt.tzinfo or search_range and not (search_range[0].tzinfo and search_range[1].tzinfo):
            raise ValueError('Provided datetimes needs to be timezoned')

        dt = dt

        if not search_range:
            range_start = dt + relativedelta(hour=0, minute=0, second=0)
            range_end = dt + relativedelta(days=1, hour=0, minute=0, second=0)
        else:
            range_start, range_end = search_range

        if not range_start <= dt <= range_end:
            return None
        work_intervals = sorted(
            self._work_intervals_batch(range_start, range_end, resource, compute_leaves=compute_leaves)[resource.id],
            key=lambda i: abs(interval_dt(i) - dt),
        )
        return interval_dt(work_intervals[0]) if work_intervals else None

    def _get_unusual_days(self, start_dt, end_dt):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_unusual_days(start_dt, end_dt)
        
        if not self:
            return {}
        self.ensure_one()
        if not start_dt.tzinfo:
            start_dt = start_dt.replace(tzinfo=utc)
        if not end_dt.tzinfo:
            end_dt = end_dt.replace(tzinfo=utc)

        works = {d[0].date() for d in self._work_intervals_batch(start_dt, end_dt)[False]}
        return {fields.Date.to_string(day.date()): (day.date() not in works) for day in rrule(DAILY, start_dt, until=end_dt)}
    
    def get_work_hours_count(self, start_dt, end_dt, compute_leaves=True, domain=None):
        if not self.env.user.lang == 'fa_IR':
            return super().get_work_hours_count(start_dt, end_dt, compute_leaves=True, domain=None)
        self.ensure_one()
        # Set timezone in UTC if no timezone is explicitly given
        start_dt = start_dt
        end_dt = end_dt
        if compute_leaves:
            intervals = self._work_intervals_batch(start_dt, end_dt, domain=domain)[False]
        else:
            intervals = self._attendance_intervals_batch(start_dt, end_dt)[False]

        return sum(
            (stop - start).total_seconds() / 3600
            for start, stop, meta in intervals
        )
        
    def _adjust_to_calendar(self, start, end, compute_leaves=True):
        if not self.env.user.lang == 'fa_IR':
            return super().adjust_to_calendar(start, end, compute_leaves=True)
        
        start, revert_start_tz = make_aware(start)
        end, revert_end_tz = make_aware(end)
        result = {}
        for resource in self:
            start, end = start, end
            search_range = [
                start + relativedelta(hour=0, minute=0, second=0),
                end + relativedelta(days=1, hour=0, minute=0, second=0),
            ]
            calendar_start = resource.calendar_id._get_closest_work_time(start, resource=resource, search_range=search_range,
                                                                         compute_leaves=compute_leaves)
            search_range[0] = start
            calendar_end = resource.calendar_id._get_closest_work_time(end if end > start else start, match_end=True,
                                                                       resource=resource, search_range=search_range,
                                                                       compute_leaves=compute_leaves)
            result[resource] = (
                calendar_start and revert_start_tz(calendar_start),
                calendar_end and revert_end_tz(calendar_end),
            )
        return result

    def _get_unavailable_intervals(self, start, end):
        if not self.env.user.lang == 'fa_IR':
            return super()._get_unavailable_intervals(start, end)
        
        start_datetime = start
        end_datetime = end
        resource_mapping = {}
        calendar_mapping = defaultdict(lambda: self.env['resource.resource'])
        for resource in self:
            calendar_mapping[resource.calendar_id] |= resource

        for calendar, resources in calendar_mapping.items():
            resources_unavailable_intervals = calendar._unavailable_intervals_batch(start_datetime, end_datetime, resources, tz=timezone(calendar.tz))
            resource_mapping.update(resources_unavailable_intervals)
        return resource_mapping


class ResourceCalendarLeaves(models.Model):
    _inherit = "resource.calendar.leaves"

    def default_get(self, fields_list):
        if not self.env.user.lang == 'fa_IR':
            return super().default_get(fields_list)
        
        res = super().default_get(fields_list)
        if 'date_from' in fields_list and 'date_to' in fields_list and not res.get('date_from') and not res.get('date_to'):
            # Then we give the current day and we search the begin and end hours for this day in resource.calendar of the current company
            today = fields.Datetime.now()
          
            date_from = datetime.combine(today, time.min)
            date_to = datetime.combine(today, time.max)
            intervals = self.env.company.resource_calendar_id._work_intervals_batch(date_from.replace(tzinfo=utc), date_to.replace(tzinfo=utc))[False]
            if intervals:  # Then we stop and return the dates given in parameter
                list_intervals = [(start, stop) for start, stop, records in intervals]  # Convert intervals in interval list
                date_from = list_intervals[0][0]  # We take the first date in the interval list
                date_to = list_intervals[-1][1]  # We take the last date in the interval list
            res.update(
                date_from=date_from,
                date_to=date_to
            )
        return res
