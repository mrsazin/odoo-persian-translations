# -*- coding: utf-8 -*-

from . import models
from . import hr_payslip
from . import hr_leave_type
# from . import hr_contract
# from . import resource
# from . import resource_resource