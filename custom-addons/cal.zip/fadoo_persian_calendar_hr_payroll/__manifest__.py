# -*- coding: utf-8 -*-
{
    'name': "fadoo_persian_calendar_hr_payroll",
    'summary': """Persian Calendar""",
    'description': """Persian Calendar """,
    'author': "Fadoo",
    'website': "https://www.fadoo.ir",
    'category': 'Localization/Iran',
    'version': '1.0.1',
    'depends': ['hr_payroll', 'hr_work_entry_contract', 'hr_work_entry_contract_planning', 'resource', 'fadoo_calendar'],
    'auto_install': True,
    'license': 'LGPL-3',
}
