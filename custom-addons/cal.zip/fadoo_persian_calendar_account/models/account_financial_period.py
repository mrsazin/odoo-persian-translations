# -*- coding: utf-8 -*-
import datetime

import jdatetime
from odoo.addons.fadoo_calendar.models.res_company import MONTH_SELECTION

from odoo import _, api, fields, models


class FadooResCompany(models.Model):
    _inherit = "res.company"

    fiscalyear_last_month = fields.Selection(MONTH_SELECTION, default='12', required=True)
    
class FadooFinancialYearOpeningWizard(models.TransientModel):
    _name = "account.financial.year.op"
    _inherit = "account.financial.year.op"
    
    @api.model
    def get_views(self, views, options=None):
        self.env['account.financial.year.op'].clear_caches()
        res = super().get_views(views, options)
        return res
    
    fiscalyear_last_month = fields.Selection(related="company_id.fiscalyear_last_month",
                                             readonly=False, required=True,
                                             help="The last day of the month will be used if the chosen day doesn't exist.")

    def read(self, fields=None, load='_classic_read'):
        res = super(FadooFinancialYearOpeningWizard,self).read(fields, load)
        if self.env.user.lang == 'fa_IR':
            end_date = jdatetime.date.fromgregorian(year=res[0]['opening_date'].year,month=int(res[0]['fiscalyear_last_month']),day=res[0]['fiscalyear_last_day'])
            res[0]['fiscalyear_last_month'] = str(end_date.month)
            res[0]['fiscalyear_last_day'] = end_date.day
        return res
    
    def write(self, vals):
        # Amazing workaround: non-stored related fields on company are a BAD idea since the 3 fields
        # must follow the constraint '_check_fiscalyear_last_day'. The thing is, in case of related
        # fields, the inverse write is done one value at a time, and thus the constraint is verified
        # one value at a time... so it is likely to fail.
        if self.env.user.lang == 'fa_IR':
            for wiz in self:
                if vals.get('opening_date'):
                    aod = datetime.datetime.strptime(vals['opening_date'],'%Y-%M-%d').date()
                else:
                    aod = wiz.company_id.account_opening_date
                aod_persian_year = jdatetime.date.fromgregorian(year=aod.year,month=aod.month,day=aod.day).year
                end_date = jdatetime.date.fromgregorian(year=wiz.company_id.account_opening_date.year,
                                                        month=int(wiz.company_id.fiscalyear_last_month),
                                                        day=wiz.company_id.fiscalyear_last_day)
                fld = vals.get('fiscalyear_last_day') or end_date.day
                flm = vals.get('fiscalyear_last_month') or end_date.month
                jdate = jdatetime.date.togregorian(jdatetime.date(year=aod_persian_year,month=int(flm),day=fld))
                flm = str(jdate.month)
                fld = jdate.day
            vals['fiscalyear_last_day'] = fld
            vals['fiscalyear_last_month'] = flm
            return super().write(vals)
        return super().write(vals)
