# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class Fadoo_persian_calendar_planning(models.Model):
#     _name = 'fadoo_persian_calendar_planning.fadoo_persian_calendar_planning'
#     _description = 'fadoo_persian_calendar_planning.fadoo_persian_calendar_planning'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
