# -*- coding: utf-8 -*-
from odoo import models, fields, api, _, Command
from odoo.exceptions import UserError, ValidationError
from odoo.tools.misc import format_date, formatLang
import jdatetime
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DF

class AccountPayment(models.Model):
    _inherit = "account.payment"

    def _get_aml_default_display_name_list(self):
        """ Hook allowing custom values when constructing the default label to set on the journal items.

        :return: A list of terms to concatenate all together. E.g.
            [
                ('label', "Vendor Reimbursement"),
                ('sep', ' '),
                ('amount', "$ 1,555.00"),
                ('sep', ' - '),
                ('date', "05/14/2020"),
            ]
        """
        if self.env.user.lang == 'fa_IR':
            self.ensure_one()
            display_map = self._get_aml_default_display_map()
            values = [
                ('label', _("Internal Transfer") if self.is_internal_transfer else display_map[(self.payment_type, self.partner_type)]),
                ('sep', ' '),
                ('amount', formatLang(self.env, self.amount, currency_obj=self.currency_id)),
            ]
            if self.partner_id:
                values += [
                    ('sep', ' - '),
                    ('partner', self.partner_id.display_name),
                ]
            values += [
                ('sep', ' - '),
                ('date', jdatetime.date.fromgregorian(date=self.date).strftime('%Y/%m/%d')),
            ]
            return values
        return super()._get_aml_default_display_name_list()
