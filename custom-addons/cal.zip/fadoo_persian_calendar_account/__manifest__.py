# -*- coding: utf-8 -*-
{
    'name': "fadoo_persian_calendar_account",
    'summary': """Persian Calendar""",
    'description': """Persian Calendar """,
    'author': "Fadoo",
    'website': "https://www.fadoo.ir",
    'category': 'Localization/Iran',
    'version': '16.0.2',
    'depends': ['account', 'fadoo_calendar'],
    'auto_install': True,
    'license': 'LGPL-3',
}
