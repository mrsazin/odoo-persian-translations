# -*- coding: utf-8 -*-
import datetime
from itertools import chain

import jdatetime
from babel.dates import get_quarter_names
from dateutil.relativedelta import relativedelta
from odoo.addons.fadoo_calendar.globals import jdate_utils

from odoo import _, api, fields, models
from odoo.addons.account_reports.models import \
    account_aged_partner_balance as apb
# TODO CHECK fadoo calendar
# from odoo.addons.account_reports.models import \
#     account_bank_reconciliation_report as abr
from odoo.addons.account_reports.models import account_general_ledger as agl
from odoo.addons.account_reports.models import account_journal_report as acj
from odoo.addons.account_reports.models import account_partner_ledger as apl
from odoo.addons.account_reports.models import account_report as arc
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, config, date_utils, get_lang
from odoo.tools.misc import format_date as fd


def get_j_fiscal_year(date, company_id):
    company_fiscalyear_dates = company_id.compute_fiscalyear_dates(jdatetime.date.togregorian(date))
    jdate_from = jdatetime.date.fromgregorian(date=company_fiscalyear_dates['date_from'])
    jdate_to = jdatetime.date.fromgregorian(date=company_fiscalyear_dates['date_to'])
    return jdate_from, jdate_to


class FadooAccountReport(models.AbstractModel):
    _inherit = "account.report"

    def format_date(self, options, dt_filter='date'):
        date_from = fields.Date.from_string(options[dt_filter]['date_from'])
        date_to = fields.Date.from_string(options[dt_filter]['date_to'])
        return self._get_dates_period(date_from, date_to, options['date']['mode'])['string']

    def get_pdf(self, options):
        # As the assets are generated during the same transaction as the rendering of the
        # templates calling them, there is a scenario where the assets are unreachable: when
        # you make a request to read the assets while the transaction creating them is not done.
        # Indeed, when you make an asset request, the controller has to read the `ir.attachment`
        # table.
        # This scenario happens when you want to print a PDF report for the first time, as the
        # assets are not in cache and must be generated. To workaround this issue, we manually
        # commit the writes in the `ir.attachment` table. It is done thanks to a key in the context.
        if not config['test_enable']:
            self = self.with_context(commit_assetsbundle=True)

        base_url = self.env['ir.config_parameter'].sudo().get_param(
            'report.url') or self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        rcontext = {
            'mode': 'print',
            'base_url': base_url,
            'company': self.env.company,
        }

        body_html = self.with_context(print_mode=True).get_html(options)
        body = self.env['ir.ui.view']._render_template(
            "account_reports.print_template",
            values=dict(rcontext, body_html=body_html),
        )

        ########## Overrided ##########
        if self.env.user.lang == 'fa_IR':
            body = body.replace(b'<html>', b'<html dir="rtl">')
        ########## ######### ##########

        footer = self.env['ir.actions.report']._render_template("web.internal_layout", values=rcontext)
        footer = self.env['ir.actions.report']._render_template(
            "web.minimal_layout", values=dict(rcontext, subst=True, body=Markup(footer.decode())))

        landscape = False
        if len(self.with_context(print_mode=True).get_header(options)[-1]) > 5:
            landscape = True

        return self.env['ir.actions.report']._run_wkhtmltopdf(
            [body],
            footer=footer.decode(),
            landscape=landscape,
            specific_paperformat_args={
                'data-report-margin-top': 10,
                'data-report-header-spacing': 10
            }
        )

    def _get_cell_type_value(self, cell):
        ########## Overrided ##########
        """
        if 'date' not in cell.get('class', '') or not cell.get('name'):
            # cell is not a date
            return ('text', cell.get('name', ''))
        if isinstance(cell['name'], (float, datetime.date, datetime.datetime)):
            # the date is xlsx compatible
            return ('date', cell['name'])
        try:
            # the date is parsable to a xlsx compatible date
            lg = self.env['res.lang']._lang_get(self.env.user.lang) or get_lang(self.env)
            return ('date', datetime.datetime.strptime(cell['name'], lg.date_format))
        except:
            # the date is not parsable thus is returned as text
            return ('text', cell['name'])
        """
        if self.env.user.lang == 'fa_IR':
            return ('text', cell.get('name',''))
        else:
            return super(FadooAccountReport, self)._get_cell_type_value(cell)
        ########## ######### ##########

    def _register_hook(self):

        def _init_options_date(self, options, previous_options=None):
            """ Initialize the 'date' options key.

            :param options:             The current report options to build.
            :param previous_options:    The previous options coming from another report.
            """
            previous_date = (previous_options or {}).get('date', {})
            previous_date_to = previous_date.get('date_to')
            previous_date_from = previous_date.get('date_from')
            previous_mode = previous_date.get('mode')
            previous_filter = previous_date.get('filter', 'custom')

            default_filter = self.default_opening_date_filter
            options_mode = 'range' if self.filter_date_range else 'single'
            date_from = date_to = period_type = False

            if previous_mode == 'single' and options_mode == 'range':
                # 'single' date mode to 'range'.
                if previous_filter:
                    date_to = fields.Date.from_string(previous_date_to or previous_date_from)
                    date_from = self.env.company.compute_fiscalyear_dates(date_to)['date_from']
                    options_filter = 'custom'
                else:
                    options_filter = default_filter
            elif previous_mode == 'range' and options_mode == 'single':
                # 'range' date mode to 'single'.
                if previous_filter == 'custom':
                    date_to = fields.Date.from_string(previous_date_to or previous_date_from)
                    date_from = self.env.user.lang == 'fa_IR' and jdate_utils.jget_month(date_to)[0] or date_utils.get_month(date_to)[0]
                    options_filter = 'custom'
                elif previous_filter:
                    options_filter = previous_filter
                else:
                    options_filter = default_filter
            elif (previous_mode is None or previous_mode == options_mode) and previous_date:
                # Same date mode.
                if previous_filter == 'custom':
                    if options_mode == 'range':
                        date_from = fields.Date.from_string(previous_date_from)
                        date_to = fields.Date.from_string(previous_date_to)
                    else:
                        date_to = fields.Date.from_string(previous_date_to or previous_date_from)
                        date_from = self.env.user.lang == 'fa_IR' and jdate_utils.jget_month(date_to)[0] or date_utils.get_month(date_to)[0]

                    options_filter = 'custom'
                else:
                    options_filter = previous_filter
            else:
                # Default.
                options_filter = default_filter

            # Compute 'date_from' / 'date_to'.
            if not date_from or not date_to:
                if options_filter == 'today':
                    date_to = fields.Date.context_today(self)
                    date_from = self.env.company.compute_fiscalyear_dates(date_to)['date_from']
                    period_type = 'today'
                elif 'month' in options_filter:
                    date_from, date_to = self.env.user.lang == 'fa_IR' and jdate_utils.jget_month(fields.Date.context_today(self)) or date_utils.get_month(fields.Date.context_today(self))
                    period_type = 'month'
                elif 'quarter' in options_filter:
                    date_from, date_to = self.env.user.lang == 'fa_IR' and  jdate_utils.jget_quarter(fields.Date.context_today(self)) or date_utils.get_quarter(fields.Date.context_today(self))
                    period_type = 'quarter'
                elif 'year' in options_filter:
                    company_fiscalyear_dates = self.env.company.compute_fiscalyear_dates(fields.Date.context_today(self))
                    date_from = company_fiscalyear_dates['date_from']
                    date_to = company_fiscalyear_dates['date_to']
                elif 'tax_period' in options_filter:
                    date_from, date_to = self.env.company._get_tax_closing_period_boundaries(fields.Date.context_today(self))

            options['date'] = self._get_dates_period(
                date_from,
                date_to,
                options_mode,
                period_type=period_type,
            )

            if 'last' in options_filter:
                options['date'] = self._get_dates_previous_period(options, options['date'], tax_period='tax_period' in options_filter)

            options['date']['filter'] = options_filter

        def _get_dates_period(self, date_from, date_to, mode, period_type=None):
            '''Compute some information about the period:
            * The name to display on the report.
            * The period type (e.g. quarter) if not specified explicitly.

            :param options:     The report options.
            :param date_from:   The starting date of the period.
            :param date_to:     The ending date of the period.
            :param period_type: The type of the interval date_from -> date_to.
            :return:            A dictionary containing:
                * date_from * date_to * string * period_type *
            '''
            def match(dt_from, dt_to):
                return (dt_from, dt_to) == (date_from, date_to)

            string = None
            #################################################################
            # TODO CHECK fadoo calendar 
            if self.env.user.lang == 'fa_IR':
                # If no date_from or not date_to, we are unable to determine a period
                if not period_type or period_type == 'custom':
                    date = date_to or date_from
                    company_fiscalyear_dates = self.env.company.compute_fiscalyear_dates(date)

                    jdate = jdatetime.date.fromgregorian(date=date)

                    jmonth_date_from, jmonth_date_to = jdate_utils.jget_month(jdate)
                    month_date_from  = jdatetime.date.togregorian(jmonth_date_from)
                    month_date_to  = jdatetime.date.togregorian(jmonth_date_to)

                    jquarter_date_from, jquarter_date_to = jdate_utils.get_quarter(jdate)
                    quarter_date_from = jdatetime.date.togregorian(jquarter_date_from)
                    quarter_date_to = jdatetime.date.togregorian(jquarter_date_to)

                    jyear_date_from,  jyear_date_to = jdate_utils.get_year(jdate)
                    year_date_from = jdatetime.date.togregorian(jyear_date_from)
                    year_date_to = jdatetime.date.togregorian(jyear_date_to)

                    jfiscalyear_date_from,  jfiscalyear_date_to = get_j_fiscal_year(jdate, self.env.company)
                    fiscalyear_date_from = jdatetime.date.togregorian(jfiscalyear_date_from)
                    fiscalyear_date_to = jdatetime.date.togregorian(jfiscalyear_date_to)

                    if match(fiscalyear_date_from, fiscalyear_date_to):
                        period_type = 'fiscalyear'
                    elif match(year_date_from, year_date_to):
                        period_type = 'year'
                    elif match(quarter_date_from, quarter_date_to):
                        period_type = 'quarter'
                    elif match(month_date_from, month_date_to):
                        period_type = 'month'
                    elif match(date, fields.Date.today()):
                        period_type = 'today'
                    else:
                        period_type = 'custom'

                if not string:
                    if mode == 'single':
                        string = _('As of %s') % (jdatetime.date.fromgregorian(date=date_to))
                    elif period_type == 'fiscalyear':
                        string = 'سال مالی %s/%s - %s/%s' % (jfiscalyear_date_from.year, jfiscalyear_date_from.month,
                                                            jfiscalyear_date_to.year, jfiscalyear_date_to.month)
                    elif period_type == 'year':
                        string = jdatetime.date.fromgregorian(date=date_to).strftime('%Y')
                    elif period_type == 'quarter':
                        string = u'%s\N{NO-BREAK SPACE}%s' % (jdate_utils.get_quarter_name(
                            jdatetime.date.fromgregorian(date=date_to), 'fa_IR'), jdatetime.date.fromgregorian(date=date_to).year)
                    elif period_type == 'month':
                        string = u'%s\N{NO-BREAK SPACE}%s' % (jdate_utils.get_month_name(jdatetime.date.fromgregorian(
                            date=date_to), 'fa_IR'), jdatetime.date.fromgregorian(date=date_to).year)
                    else:
                        dt_from_str = jdatetime.date.fromgregorian(date=date_from).strftime("%d-%m-%Y")
                        dt_to_str = jdatetime.date.fromgregorian(date=date_to).strftime("%d-%m-%Y")
                        string = 'از %s\nتا  %s' % (dt_from_str, dt_to_str)
            #################################################################
            elif not period_type or period_type == 'custom':
                # If no date_from or not date_to, we are unable to determine a period
                date = date_to or date_from
                company_fiscalyear_dates = self.env.company.compute_fiscalyear_dates(date)
                if match(company_fiscalyear_dates['date_from'], company_fiscalyear_dates['date_to']):
                    period_type = 'fiscalyear'
                    if company_fiscalyear_dates.get('record'):
                        string = company_fiscalyear_dates['record'].name
                elif match(*date_utils.get_month(date)):
                    period_type = 'month'
                elif match(*date_utils.get_quarter(date)):
                    period_type = 'quarter'
                elif match(*date_utils.get_fiscal_year(date)):
                    period_type = 'year'
                elif match(date_utils.get_month(date)[0], fields.Date.today()):
                    period_type = 'today'
                else:
                    period_type = 'custom'
                # TODO check fadoo 
            elif period_type == 'fiscalyear':
                date = date_to or date_from
                company_fiscalyear_dates = self.env.company.compute_fiscalyear_dates(date)
                record = company_fiscalyear_dates.get('record')
                string = record and record.name

            if not string:
                fy_day = self.env.company.fiscalyear_last_day
                fy_month = int(self.env.company.fiscalyear_last_month)
                if mode == 'single':
                    string = _('As of %s') % (fd(self.env, fields.Date.to_string(date_to)))
                elif period_type == 'year' or (
                        period_type == 'fiscalyear' and (date_from, date_to) == date_utils.get_fiscal_year(date_to)):
                    string = date_to.strftime('%Y')
                elif period_type == 'fiscalyear' and (date_from, date_to) == date_utils.get_fiscal_year(date_to, day=fy_day, month=fy_month):
                    string = '%s - %s' % (date_to.year - 1, date_to.year)
                elif period_type == 'month':
                    string = fd(self.env, fields.Date.to_string(date_to), date_format='MMM yyyy')
                elif period_type == 'quarter':
                    quarter_names = get_quarter_names('abbreviated', locale=get_lang(self.env).code)
                    string = u'%s\N{NO-BREAK SPACE}%s' % (
                        quarter_names[date_utils.get_quarter_number(date_to)], date_to.year)
                else:
                    dt_from_str = fd(self.env, fields.Date.to_string(date_from))
                    dt_to_str = fd(self.env, fields.Date.to_string(date_to))
                    string = _('From %s\nto  %s') % (dt_from_str, dt_to_str)

            return {
                'string': string,
                'period_type': period_type,
                'mode': mode,
                'date_from': date_from and fields.Date.to_string(date_from) or False,
                'date_to': fields.Date.to_string(date_to),
            }

        def _get_dates_previous_period(self, options, period_vals, tax_period=False):
            '''Shift the period to the previous one.

            :param options:     The report options.
            :param period_vals: A dictionary generated by the _get_dates_period method.
            :return:            A dictionary containing:
                * date_from * date_to * string * period_type *
            '''
            period_type = period_vals['period_type']
            mode = period_vals['mode']
            strict_range = period_vals.get('strict_range', False)
            date_from = fields.Date.from_string(period_vals['date_from'])
            date_to = date_from - datetime.timedelta(days=1)

            #################################################################
            if self.env.user.lang == 'fa_IR':
                jdate_to = jdatetime.date.fromgregorian(date=date_to)

                jmonth_date_from, jmonth_date_to = jdate_utils.get_month(jdate_to)
                month_date_from = jdatetime.date.togregorian(jmonth_date_from)
                month_date_to = jdatetime.date.togregorian(jmonth_date_to)

                jquarter_date_from, jquarter_date_to = jdate_utils.get_quarter(jdate_to)
                quarter_date_from = jdatetime.date.togregorian(jquarter_date_from)
                quarter_date_to = jdatetime.date.togregorian(jquarter_date_to)

                jfiscalyear_date_from,  jfiscalyear_date_to = get_j_fiscal_year(jdate_to, self.env.company)
                fiscalyear_date_from = jdatetime.date.togregorian(jfiscalyear_date_from)
                fiscalyear_date_to = jdatetime.date.togregorian(jfiscalyear_date_to)

                if period_type == 'fiscalyear':
                    # Don't pass the period_type to _get_dates_period to be able to retrieve the account.fiscal.year record if
                    # necessary.
                    company_fiscalyear_dates = self.env.company.compute_fiscalyear_dates(date_to)
                    return self._get_dates_period(company_fiscalyear_dates['date_from'], company_fiscalyear_dates['date_to'], mode)
                if period_type in ('month', 'today', 'custom'):
                    return self._get_dates_period(month_date_from, month_date_to, mode, period_type='month')
                if period_type == 'quarter':
                    return self._get_dates_period(quarter_date_from, quarter_date_to, mode, period_type='quarter')
                if period_type == 'year':
                    return self._get_dates_period(fiscalyear_date_from, fiscalyear_date_to, mode, period_type='year')
                return None
            #################################################################
            else:
                if period_type == 'fiscalyear':
                    # Don't pass the period_type to _get_dates_period to be able to retrieve the account.fiscal.year record if
                    # necessary.
                    company_fiscalyear_dates = self.env.company.compute_fiscalyear_dates(date_to)
                    return self._get_dates_period(company_fiscalyear_dates['date_from'], company_fiscalyear_dates['date_to'], mode)
                if period_type in ('month', 'today', 'custom'):
                    return self._get_dates_period(*date_utils.get_month(date_to), mode, period_type='month')
                if period_type == 'quarter':
                    return self._get_dates_period(*date_utils.get_quarter(date_to), mode, period_type='quarter')
                if period_type == 'year':
                    return self._get_dates_period(*date_utils.get_fiscal_year(date_to), mode, period_type='year')
                return None

        def _get_dates_previous_year(self, options, period_vals):
            '''Shift the period to the previous year.

            :param options:     The report options.
            :param period_vals: A dictionary generated by the _get_dates_period method.
            :return:            A dictionary containing:
                * date_from * date_to * string * period_type *
            '''
            period_type = period_vals['period_type']
            mode = period_vals['mode']
            strict_range = period_vals.get('strict_range', False)
            date_from = fields.Date.from_string(period_vals['date_from'])
            date_from = date_from - relativedelta(years=1)
            date_to = fields.Date.from_string(period_vals['date_to'])
            date_to = date_to - relativedelta(years=1)

            #################################################################
            if self.env.user.lang == 'fa_IR':
                jdate_to = jdatetime.date.fromgregorian(date=date_to)

                jmonth_date_from, jmonth_date_to = jdate_utils.get_month(jdate_to)
                month_date_from = jdatetime.date.togregorian(jmonth_date_from)
                month_date_to = jdatetime.date.togregorian(jmonth_date_to)

                if period_type == 'month':
                    date_from, date_to = month_date_from, month_date_to
            #################################################################
            else:
                if period_type == 'month':
                    date_from, date_to = date_utils.get_month(date_to)
            return self._get_dates_period(date_from, date_to, mode, period_type=period_type)

        arc.AccountReport._init_options_date = _init_options_date
        arc.AccountReport._get_dates_period = _get_dates_period
        arc.AccountReport._get_dates_previous_period = _get_dates_previous_period
        arc.AccountReport._get_dates_previous_year = _get_dates_previous_year


class FadooJournalReportCustomHandler(models.AbstractModel):
    _inherit = "account.journal.report.handler"

    def _register_hook(self):

        @api.model
        def _get_first_move_line(self, options, parent_key, line_key, values, is_unreconciled_payment):
            """ Returns the first line of a move.
            It is different from the other lines, as it contains more information such as the date, partner, and a link to the move itself.

            :param options: The report options.
            :param parent_key: The id of the lines that should be parenting the aml lines. Should be the group line (either the journal, or month).
            :param line_key: The id of the move line itself.
            :param values: The values of the move line.
            :param new_balance: The new balance of the move line, if any. Use to display the cumulated balance for bank journals.
            """
            report = self.env['account.report']
            # Helps to format the line. If a line is linked to a partner but the account isn't receivable or payable, we want to display it in blue.
            columns = []
            for column_group_key, column_group_options in report._split_options_per_column_group(options).items():
                values = values[column_group_key]
                balance = False if column_group_options.get('show_payment_lines') and is_unreconciled_payment else values.get('cumulated_balance')
                not_receivable_with_partner = values['partner_name'] and values['account_type'] not in ('asset_receivable', 'liability_payable')
                columns.extend([
                    {'name': '%s %s' % (values['account_code'], '' if values['partner_name'] else values['account_name']), 'name_right': values['partner_name'], 'class': 'o_account_report_line_ellipsis' + (' color-blue' if not_receivable_with_partner else ''), 'template': 'account_reports.cell_template_journal_audit_report', 'style': 'text-align:left;'},
                    {'name': values['name'], 'class': 'o_account_report_line_ellipsis', 'style': 'text-align:left;'},
                    {'name': report.format_value(options,value=values['debit'], figure_type='monetary'), 'no_format': values['debit'], 'class': 'number'},
                    {'name': report.format_value(options,value=values['credit'], figure_type='monetary'), 'no_format': values['credit'], 'class': 'number'},
                ] + self._get_move_line_additional_col(column_group_options, balance, values, is_unreconciled_payment))
            if self.env.user.lang == 'fa_IR' :
                values['date'] = jdatetime.date.fromgregorian(year=values['date'].year,month=values['date'].month,day=values['date'].day).strftime('%Y/%m/%d')
            return {
                'id': line_key,
                'name': values['move_name'],
                'level': 3,
                'date': self.env.user.lang == 'fa_IR' and values['date'] or fd(self.env, values['date']),
                'columns': columns,
                'parent_id': parent_key,
                'move_id': values['move_id'],
            }
            
        acj.JournalReportCustomHandler._get_first_move_line = _get_first_move_line

class FadooAccountGeneralLedger(models.AbstractModel):
    _inherit = "account.general.ledger.report.handler"

    def _register_hook(self):

        @api.model
        def _get_aml_line(self, report, parent_line_id, options, eval_dict, init_bal_by_col_group):
            line_columns = []
            for column in options['columns']:
                col_expr_label = column['expression_label']
                col_value = eval_dict[column['column_group_key']].get(col_expr_label)

                if col_value is None:
                    line_columns.append({})
                else:
                    col_class = 'number'

                    if col_expr_label == 'amount_currency':
                        currency = self.env['res.currency'].browse(eval_dict[column['column_group_key']]['currency_id'])

                        if currency != self.env.company.currency_id:
                            formatted_value = report.format_value(options,value=col_value, currency=currency, figure_type=column['figure_type'])
                        else:
                            formatted_value = ''
                    elif col_expr_label == 'invoice_date':
                        if self.env.user.lang == 'fa_IR' :
                            col_value = jdatetime.date.fromgregorian(year=col_value.year,month=col_value.month,day=col_value.day).strftime('%Y/%m/%d')
                            formatted_value = col_value
                        else:
                            formatted_value = fd(self.env, col_value)
                        col_class = 'date'
                    elif col_expr_label == 'balance':
                        col_value += init_bal_by_col_group[column['column_group_key']]
                        formatted_value = report.format_value(options,value=col_value, figure_type=column['figure_type'], blank_if_zero=False)
                    elif col_expr_label == 'communication' or col_expr_label == 'partner_name':
                        col_class = 'o_account_report_line_ellipsis'
                        formatted_value = report.format_value(options,value=col_value, figure_type=column['figure_type'])
                    else:
                        formatted_value = report.format_value(options,value=col_value, figure_type=column['figure_type'])
                        if col_expr_label not in ('debit', 'credit'):
                            col_class = ''

                    line_columns.append({
                        'name': formatted_value,
                        'no_format': col_value,
                        'class': col_class,
                    })

            first_column_group_key = options['columns'][0]['column_group_key']
            if eval_dict[first_column_group_key]['payment_id']:
                caret_type = 'account.payment'
            else:
                caret_type = 'account.move.line'
            aml_id = None
            move_name = None
            caret_type = None
            for column_group_dict in eval_dict.values():
                aml_id = column_group_dict.get('id', '')
                if aml_id:
                    if column_group_dict.get('payment_id'):
                        caret_type = 'account.payment'
                    else:
                        caret_type = 'account.move.line'
                    move_name = column_group_dict['move_name']
                    date = str(column_group_dict.get('date', ''))
                    break

            return {
                'id': report._get_generic_line_id('account.move.line', aml_id, parent_line_id=parent_line_id, markup=date),
                'caret_options': caret_type,
                'parent_id': parent_line_id,
                'name': eval_dict[first_column_group_key]['move_name'],
                'columns': line_columns,
                'level': 2,
            }
            
        agl.GeneralLedgerCustomHandler._get_aml_line = _get_aml_line


class FadooAccountPartnerLedger(models.AbstractModel):
    _inherit = "account.partner.ledger.report.handler"

    def _register_hook(self):

        @api.model
        def _get_report_line_move_line(self, options, aml_query_result, partner_line_id, init_bal_by_col_group, level_shift=0):
            if aml_query_result['payment_id']:
                caret_type = 'account.payment'
            else:
                caret_type = 'account.move.line'

            columns = []
            report = self.env['account.report']
            for column in options['columns']:
                col_expr_label = column['expression_label']
                if col_expr_label == 'ref':
                    col_value = report._format_aml_name(aml_query_result['name'], aml_query_result['ref'], aml_query_result['move_name'])
                else:
                    col_value = aml_query_result[col_expr_label] if column['column_group_key'] == aml_query_result['column_group_key'] else None

                if col_value is None:
                    columns.append({})
                else:
                    col_class = 'number'

                    if col_expr_label == 'date_maturity':
                        if self.env.user.lang == 'fa_IR':
                            col_value = jdatetime.date.fromgregorian(year=col_value.year,month=col_value.month,day=col_value.day).strftime('%Y/%m/%d')
                            formatted_value = col_value
                        else:
                            formatted_value = fd(self.env, fields.Date.from_string(col_value))
                        col_class = 'date'
                    elif col_expr_label == 'amount_currency':
                        currency = self.env['res.currency'].browse(aml_query_result['currency_id'])
                        formatted_value = report.format_value(options,value=col_value, currency=currency, figure_type=column['figure_type'])
                    elif col_expr_label == 'balance':
                        col_value += init_bal_by_col_group[column['column_group_key']]
                        formatted_value = report.format_value(options,value=col_value, figure_type=column['figure_type'], blank_if_zero=column['blank_if_zero'])
                    else:
                        if col_expr_label == 'ref':
                            col_class = 'o_account_report_line_ellipsis'
                        elif col_expr_label not in ('debit', 'credit'):
                            col_class = ''
                        formatted_value = report.format_value(options,value=col_value, figure_type=column['figure_type'])

                    columns.append({
                        'name': formatted_value,
                        'no_format': col_value,
                        'class': col_class,
                    })
            # TODO CHECK fadoo calendar
            # Expected singleton: account.report()
            return {
                'id': report._get_generic_line_id('account.move.line', aml_query_result['id'], parent_line_id=partner_line_id),
                'parent_id': partner_line_id,
                'name': jdatetime.datetime.fromgregorian(date=aml_query_result['date']).strftime(DEFAULT_SERVER_DATE_FORMAT) if self.env.user.lang == 'fa_IR' else fd(self.env, aml_query_result['date']),
                'class': 'text-muted' if aml_query_result['key'] == 'indirectly_linked_aml' else 'text',  # do not format as date to prevent text centering
                'columns': columns,
                'caret_options': caret_type,
                'level': 2 + level_shift,
            }

        apl.PartnerLedgerCustomHandler._get_report_line_move_line = _get_report_line_move_line


class FadooAgedPartnerBalanceCustomHandler(models.AbstractModel):
    _inherit = "account.aged.partner.balance.report.handler"

    def _register_hook(self):

        @api.model
        def _aged_partner_report_custom_engine_common(self, options, internal_type, current_groupby, next_groupby, offset=0, limit=None):
            report = self.env['account.report'].browse(options['report_id'])
            report._check_groupby_fields((next_groupby.split(',') if next_groupby else []) + ([current_groupby] if current_groupby else []))

            def minus_days(date_obj, days):
                return fields.Date.to_string(date_obj - relativedelta(days=days))

            date_to = fields.Date.from_string(options['date']['date_to'])
            periods = [
                (False, fields.Date.to_string(date_to)),
                (minus_days(date_to, 1), minus_days(date_to, 30)),
                (minus_days(date_to, 31), minus_days(date_to, 60)),
                (minus_days(date_to, 61), minus_days(date_to, 90)),
                (minus_days(date_to, 91), minus_days(date_to, 120)),
                (minus_days(date_to, 121), False),
            ]

            def build_result_dict(report, query_res_lines):
                rslt = {f'period{i}': 0 for i in range(len(periods))}

                for query_res in query_res_lines:
                    for i in range(len(periods)):
                        period_key = f'period{i}'
                        rslt[period_key] += query_res[period_key]
                idate = None
                ddate = None
                edate = None
                if len(query_res['invoice_date']) == 1:
                    idate = query_res['invoice_date'][0]
                    if self.env.user.lang == 'fa_IR':
                        idate = jdatetime.date.fromgregorian(year=idate.year,month=idate.month,day=idate.day)
                        idate = datetime.date(idate.year,idate.month,idate.day)
                if len(query_res['due_date']) == 1:
                    ddate = query_res['due_date'][0]
                    if self.env.user.lang == 'fa_IR':
                        ddate = jdatetime.date.fromgregorian(year=ddate.year,month=ddate.month,day=ddate.day)
                        ddate = datetime.date(ddate.year,ddate.month,ddate.day)
                if len(query_res['expected_date']) == 1 and query_res['expected_date'][0] or len(query_res['due_date']) == 1 and query_res['due_date'][0]:
                    edate = query_res['expected_date'][0] or query_res['due_date'][0]
                    if self.env.user.lang == 'fa_IR':
                        edate = jdatetime.date.fromgregorian(year=edate.year,month=edate.month,day=edate.day)
                        edate = datetime.date(edate.year,edate.month,edate.day)
                if current_groupby == 'id':
                    query_res = query_res_lines[0] # We're grouping by id, so there is only 1 element in query_res_lines anyway
                    currency = self.env['res.currency'].browse(query_res['currency_id'][0]) if len(query_res['currency_id']) == 1 else None
                    expected_date = len(query_res['expected_date']) == 1 and query_res['expected_date'][0] or len(query_res['due_date']) == 1 and query_res['due_date'][0]
                    rslt.update({
                        'invoice_date': idate,
                        'due_date': ddate,
                        'amount_currency': query_res['amount_currency'],
                        'currency_id': query_res['currency_id'][0] if len(query_res['currency_id']) == 1 else None,
                        'currency': currency.display_name if currency else None,
                        'account_name': query_res['account_name'][0] if len(query_res['account_name']) == 1 else None,
                        'expected_date': edate,
                        'total': None,
                        'has_sublines': query_res['aml_count'] > 0,

                        # Needed by the custom_unfold_all_batch_data_generator, to speed-up unfold_all
                        'partner_id': query_res['partner_id'][0] if query_res['partner_id'] else None,
                    })
                else:
                    rslt.update({
                        'invoice_date': None,
                        'due_date': None,
                        'amount_currency': None,
                        'currency_id': None,
                        'currency': None,
                        'account_name': None,
                        'expected_date': None,
                        'total': sum(rslt[f'period{i}'] for i in range(len(periods))),
                        'has_sublines': False,
                    })

                return rslt

            # Build period table
            period_table_format = ('(VALUES %s)' % ','.join("(%s, %s, %s)" for period in periods))
            params = list(chain.from_iterable(
                (period[0] or None, period[1] or None, i)
                for i, period in enumerate(periods)
            ))
            period_table = self.env.cr.mogrify(period_table_format, params).decode(self.env.cr.connection.encoding)

            # Build query
            tables, where_clause, where_params = report._query_get(options, 'strict_range', domain=[('account_id.account_type', '=', internal_type)])

            currency_table = report._get_query_currency_table(options)
            always_present_groupby = "period_table.period_index, currency_table.rate, currency_table.precision"
            if current_groupby:
                select_from_groupby = f"account_move_line.{current_groupby} AS grouping_key,"
                groupby_clause = f"account_move_line.{current_groupby}, {always_present_groupby}"
            else:
                select_from_groupby = ''
                groupby_clause = always_present_groupby
            select_period_query = ','.join(
                f"""
                    CASE WHEN period_table.period_index = {i}
                    THEN %s * (
                        SUM(ROUND(account_move_line.balance * currency_table.rate, currency_table.precision))
                        - COALESCE(SUM(ROUND(part_debit.amount * currency_table.rate, currency_table.precision)), 0)
                        + COALESCE(SUM(ROUND(part_credit.amount * currency_table.rate, currency_table.precision)), 0)
                    )
                    ELSE 0 END AS period{i}
                """
                for i in range(len(periods))
            )

            tail_query, tail_params = report._get_engine_query_tail(offset, limit)
            query = f"""
                WITH period_table(date_start, date_stop, period_index) AS ({period_table})

                SELECT
                    {select_from_groupby}
                    %s * (
                        SUM(account_move_line.amount_currency)
                        - COALESCE(SUM(part_debit.debit_amount_currency), 0)
                        + COALESCE(SUM(part_credit.credit_amount_currency), 0)
                    ) AS amount_currency,
                    ARRAY_AGG(DISTINCT account_move_line.partner_id) AS partner_id,
                    ARRAY_AGG(account_move_line.payment_id) AS payment_id,
                    ARRAY_AGG(DISTINCT move.invoice_date) AS invoice_date,
                    ARRAY_AGG(DISTINCT COALESCE(account_move_line.date_maturity, account_move_line.date)) AS report_date,
                    ARRAY_AGG(DISTINCT account_move_line.expected_pay_date) AS expected_date,
                    ARRAY_AGG(DISTINCT account.code) AS account_name,
                    ARRAY_AGG(DISTINCT COALESCE(account_move_line.date_maturity, account_move_line.date)) AS due_date,
                    ARRAY_AGG(DISTINCT account_move_line.currency_id) AS currency_id,
                    COUNT(account_move_line.id) AS aml_count,
                    ARRAY_AGG(account.code) AS account_code,
                    {select_period_query}

                FROM {tables}

                JOIN account_journal journal ON journal.id = account_move_line.journal_id
                JOIN account_account account ON account.id = account_move_line.account_id
                JOIN account_move move ON move.id = account_move_line.move_id
                JOIN {currency_table} ON currency_table.company_id = account_move_line.company_id

                LEFT JOIN LATERAL (
                    SELECT
                        SUM(part.amount) AS amount,
                        SUM(part.debit_amount_currency) AS debit_amount_currency,
                        part.debit_move_id
                    FROM account_partial_reconcile part
                    WHERE part.max_date <= %s
                    GROUP BY part.debit_move_id
                ) part_debit ON part_debit.debit_move_id = account_move_line.id

                LEFT JOIN LATERAL (
                    SELECT
                        SUM(part.amount) AS amount,
                        SUM(part.credit_amount_currency) AS credit_amount_currency,
                        part.credit_move_id
                    FROM account_partial_reconcile part
                    WHERE part.max_date <= %s
                    GROUP BY part.credit_move_id
                ) part_credit ON part_credit.credit_move_id = account_move_line.id

                JOIN period_table ON
                    (
                        period_table.date_start IS NULL
                        OR COALESCE(account_move_line.date_maturity, account_move_line.date) <= DATE(period_table.date_start)
                    )
                    AND
                    (
                        period_table.date_stop IS NULL
                        OR COALESCE(account_move_line.date_maturity, account_move_line.date) >= DATE(period_table.date_stop)
                    )

                WHERE {where_clause}

                GROUP BY {groupby_clause}

                HAVING
                    (
                        SUM(ROUND(account_move_line.debit * currency_table.rate, currency_table.precision))
                        - COALESCE(SUM(ROUND(part_debit.amount * currency_table.rate, currency_table.precision)), 0)
                    ) != 0
                    OR
                    (
                        SUM(ROUND(account_move_line.credit * currency_table.rate, currency_table.precision))
                        - COALESCE(SUM(ROUND(part_credit.amount * currency_table.rate, currency_table.precision)), 0)
                    ) != 0
                {tail_query}
            """

            multiplicator = -1 if internal_type == 'liability_payable' else 1
            params = [
                multiplicator,
                *([multiplicator] * len(periods)),
                date_to,
                date_to,
                *where_params,
                *tail_params,
            ]
            self._cr.execute(query, params)
            query_res_lines = self._cr.dictfetchall()

            if not current_groupby:
                return build_result_dict(report, query_res_lines)
            else:
                rslt = []

                all_res_per_grouping_key = {}
                for query_res in query_res_lines:
                    grouping_key = query_res['grouping_key']
                    all_res_per_grouping_key.setdefault(grouping_key, []).append(query_res)

                for grouping_key, query_res_lines in all_res_per_grouping_key.items():
                    rslt.append((grouping_key, build_result_dict(report, query_res_lines)))

                return rslt

        apb.AgedPartnerBalanceCustomHandler._aged_partner_report_custom_engine_common = _aged_partner_report_custom_engine_common

# TODO CHECK fadoo calendar
# class FadooAccountBankReconciliationReport(models.AbstractModel):
#     _inherit = 'account.bank.reconciliation.report.handler'

#     def _register_hook(self):

#         @api.model
#         def _get_statement_report_lines(self, options, journal):
#             ''' Retrieve the journal items used by the statement lines that are not yet reconciled and then, need to be
#             displayed inside the report.
#             :param options: The report options.
#             :param journal: The journal as an account.journal record.
#             :return:        The report lines for sections about statement lines.
#             '''
#             company_currency = journal.company_id.currency_id
#             journal_currency = journal.currency_id if journal.currency_id and journal.currency_id != company_currency else False
#             report_currency = journal_currency or company_currency
#             unfold_all = options.get('unfold_all') or (
#                 self._context.get('print_mode') and not options['unfolded_lines'])

#             if not journal.default_account_id:
#                 return [], []

#             # Compute the percentage corresponding of the remaining amount to reconcile.

#             tables, where_clause, where_params = self.with_company(journal.company_id)._query_get(options, domain=[
#                 ('journal_id', '=', journal.id),
#                 ('account_id', '!=', journal.default_account_id.id),
#             ])

#             self._cr.execute('''
#                 SELECT
#                     st_line.id,
#                     move.name,
#                     move.ref,
#                     move.date,
#                     st_line.payment_ref,
#                     st_line.amount,
#                     st_line.amount_currency,
#                     st_line.foreign_currency_id,
#                     COALESCE(SUM(CASE WHEN account_move_line.account_id = %s THEN account_move_line.balance ELSE 0.0 END), 0.0) AS suspense_balance,
#                     COALESCE(SUM(CASE WHEN account_move_line.account_id = %s THEN 0.0 ELSE account_move_line.balance END), 0.0) AS other_balance
#                 FROM ''' + tables + '''
#                 JOIN account_bank_statement_line st_line ON st_line.move_id = account_move_line.move_id
#                 JOIN account_move move ON move.id = st_line.move_id
#                 WHERE ''' + where_clause + '''
#                     AND NOT st_line.is_reconciled
#                 GROUP BY
#                     st_line.id,
#                     move.name,
#                     move.ref,
#                     move.date,
#                     st_line.amount,
#                     st_line.amount_currency,
#                     st_line.foreign_currency_id
#                 ORDER BY st_line.statement_id DESC, move.date, st_line.sequence, st_line.id DESC
#             ''', [journal.suspense_account_id.id, journal.suspense_account_id.id] + where_params)

#             plus_report_lines = []
#             less_report_lines = []
#             plus_total = 0.0
#             less_total = 0.0

#             for res in self._cr.dictfetchall():

#                 # Rate representing the remaining percentage to be reconciled with something.
#                 reconcile_rate = abs(res['suspense_balance']) / \
#                     (abs(res['suspense_balance']) + abs(res['other_balance']))

#                 amount = res['amount'] * reconcile_rate

#                 if res['foreign_currency_id']:
#                     # Foreign currency.

#                     amount_currency = res['amount_currency'] * reconcile_rate
#                     foreign_currency = self.env['res.currency'].browse(res['foreign_currency_id'])

#                     monetary_columns = [
#                         {
#                             'name': selfformat_value(options,value=amount_currency, foreign_currency),
#                             'no_format': amount_currency,
#                         },
#                         {'name': foreign_currency.name},
#                         {
#                             'name': selfformat_value(options,value=amount, report_currency),
#                             'no_format': amount,
#                         },
#                     ]
#                 else:
#                     # Single currency.

#                     monetary_columns = [
#                         {'name': ''},
#                         {'name': ''},
#                         {
#                             'name': selfformat_value(options,value=amount, report_currency),
#                             'no_format': amount,
#                         },
#                     ]

#                 st_report_line = {
#                     'id': res['id'],
#                     'name': res['name'],
#                     'columns': self._apply_groups([
#                         # {'name': format_date(self.env, res['date']), 'class': 'date'},
#                         {'name': jdatetime.datetime.fromgregorian(date=res['date']).strftime(
#                             DEFAULT_SERVER_DATE_FORMAT) if self.env.user.lang == 'fa_IR' else fd(self.env, res['date']), 'class': 'date'},
#                         {'name': self._format_aml_name(res['payment_ref'], res['ref'], '/')},
#                     ] + monetary_columns),
#                     'model': 'account.bank.statement.line',
#                     'caret_options': 'account.bank.statement',
#                     'level': 3,
#                 }

#                 residual_amount = monetary_columns[2]['no_format']
#                 if residual_amount > 0.0:
#                     st_report_line['parent_id'] = 'plus_unreconciled_statement_lines'
#                     plus_total += residual_amount
#                     plus_report_lines.append(st_report_line)
#                 else:
#                     st_report_line['parent_id'] = 'less_unreconciled_statement_lines'
#                     less_total += residual_amount
#                     less_report_lines.append(st_report_line)

#                 is_parent_unfolded = unfold_all or st_report_line['parent_id'] in options['unfolded_lines']
#                 if not is_parent_unfolded:
#                     st_report_line['style'] = 'display: none;'

#             return (
#                 self._build_section_report_lines(options, journal, plus_report_lines, plus_total,
#                                                  _("Including Unreconciled Bank Statement Receipts"),
#                                                  _("%s for Transactions(+) imported from your online bank account (dated today) that "
#                                                      "are not yet reconciled in Odoo (Waiting the final reconciliation allowing finding the right "
#                                                      "account)") % journal.suspense_account_id.display_name,
#                                                  ),
#                 self._build_section_report_lines(options, journal, less_report_lines, less_total,
#                                                  _("Including Unreconciled Bank Statement Payments"),
#                                                  _("%s for Transactions(-) imported from your online bank account (dated today) that "
#                                                      "are not yet reconciled in Odoo (Waiting the final reconciliation allowing finding the right "
#                                                      "account)") % journal.suspense_account_id.display_name,
#                                                  ),
#             )

#         @api.model
#         def _get_payment_report_lines(self, options, journal):
#             ''' Retrieve the journal items used by the payment lines that are not yet reconciled and then, need to be
#             displayed inside the report.
#             :param options: The report options.
#             :param journal: The journal as an account.journal record.
#             :return:        The report lines for sections about statement lines.
#             '''
#             company_currency = journal.company_id.currency_id
#             journal_currency = journal.currency_id if journal.currency_id and journal.currency_id != company_currency else False
#             report_currency = journal_currency or company_currency
#             unfold_all = options.get('unfold_all') or (
#                 self._context.get('print_mode') and not options['unfolded_lines'])

#             accounts = journal.payment_debit_account_id + journal.payment_credit_account_id
#             if not accounts:
#                 return [], []

#             # Allow user managing payments without any statement lines.
#             # In that case, the user manages transactions only using the register payment wizard.
#             if journal.default_account_id in accounts:
#                 return [], []

#             # Include payments made in the future.
#             options_wo_date = {**options, 'date': None}

#             tables, where_clause, where_params = self.with_company(journal.company_id)._query_get(options_wo_date, domain=[
#                 ('journal_id', '=', journal.id),
#                 ('account_id', 'in', accounts.ids),
#                 ('payment_id.is_matched', '=', False)
#             ])

#             self._cr.execute('''
#                 SELECT
#                     account_move_line.account_id,
#                     account_move_line.payment_id,
#                     account_move_line.currency_id,
#                     account_move_line__move_id.name,
#                     account_move_line__move_id.ref,
#                     account_move_line__move_id.date,
#                     account.reconcile AS is_account_reconcile,
#                     SUM(account_move_line.amount_residual) AS amount_residual,
#                     SUM(account_move_line.balance) AS balance,
#                     SUM(account_move_line.amount_residual_currency) AS amount_residual_currency,
#                     SUM(account_move_line.amount_currency) AS amount_currency
#                 FROM ''' + tables + '''
#                 JOIN account_account account ON account.id = account_move_line.account_id
#                 WHERE ''' + where_clause + '''
#                 GROUP BY 
#                     account_move_line.account_id,
#                     account_move_line.payment_id,
#                     account_move_line.currency_id,
#                     account_move_line__move_id.name,
#                     account_move_line__move_id.ref,
#                     account_move_line__move_id.date,
#                     account.reconcile
#                 ORDER BY account_move_line__move_id.date DESC, account_move_line.payment_id DESC
#             ''', where_params)

#             plus_report_lines = []
#             less_report_lines = []
#             plus_total = 0.0
#             less_total = 0.0

#             for res in self._cr.dictfetchall():
#                 amount_currency = res['amount_residual_currency'] if res['is_account_reconcile'] else res['amount_currency']
#                 balance = res['amount_residual'] if res['is_account_reconcile'] else res['balance']

#                 if res['currency_id'] and journal_currency and res['currency_id'] == journal_currency.id:
#                     # Foreign currency, same as the journal one.

#                     if journal_currency.is_zero(amount_currency):
#                         continue

#                     monetary_columns = [
#                         {'name': ''},
#                         {'name': ''},
#                         {
#                             'name': selfformat_value(options,value=amount_currency, journal_currency),
#                             'no_format': amount_currency,
#                         },
#                     ]

#                 elif res['currency_id']:
#                     # Payment using a foreign currency that needs to be converted to the report's currency.

#                     foreign_currency = self.env['res.currency'].browse(res['currency_id'])
#                     journal_balance = company_currency._convert(
#                         balance, report_currency, journal.company_id, options['date']['date_to'])

#                     if foreign_currency.is_zero(amount_currency) and company_currency.is_zero(balance):
#                         continue

#                     monetary_columns = [
#                         {
#                             'name': selfformat_value(options,value=amount_currency, foreign_currency),
#                             'no_format': amount_currency,
#                         },
#                         {'name': foreign_currency.name},
#                         {
#                             'name': selfformat_value(options,value=journal_balance, report_currency),
#                             'no_format': journal_balance,
#                         },
#                     ]

#                 elif not res['currency_id'] and journal_currency:
#                     # Single currency in the payment but a foreign currency on the journal.

#                     journal_balance = company_currency._convert(
#                         balance, journal_currency, journal.company_id, options['date']['date_to'])

#                     if company_currency.is_zero(balance):
#                         continue

#                     monetary_columns = [
#                         {
#                             'name': selfformat_value(options,value=balance, company_currency),
#                             'no_format': balance,
#                         },
#                         {'name': company_currency.name},
#                         {
#                             'name': selfformat_value(options,value=journal_balance, journal_currency),
#                             'no_format': journal_balance,
#                         },
#                     ]

#                 else:
#                     # Single currency.

#                     if company_currency.is_zero(balance):
#                         continue

#                     monetary_columns = [
#                         {'name': ''},
#                         {'name': ''},
#                         {
#                             'name': selfformat_value(options,value=balance, journal_currency),
#                             'no_format': balance,
#                         },
#                     ]

#                 pay_report_line = {
#                     'id': res['payment_id'],
#                     'name': res['name'],
#                     'columns': self._apply_groups([
#                         # {'name': format_date(self.env, res['date']), 'class': 'date'},
#                         {'name': jdatetime.datetime.fromgregorian(date=res['date']).strftime(
#                             DEFAULT_SERVER_DATE_FORMAT) if self.env.user.lang == 'fa_IR' else fd(self.env, res['date']), 'class': 'date'},
#                         {'name': res['ref']},
#                     ] + monetary_columns),
#                     'model': 'account.payment',
#                     'caret_options': 'account.payment',
#                     'level': 3,
#                 }

#                 residual_amount = monetary_columns[2]['no_format']
#                 if res['account_id'] == journal.payment_debit_account_id.id:
#                     pay_report_line['parent_id'] = 'plus_unreconciled_payment_lines'
#                     plus_total += residual_amount
#                     plus_report_lines.append(pay_report_line)
#                 else:
#                     pay_report_line['parent_id'] = 'less_unreconciled_payment_lines'
#                     less_total += residual_amount
#                     less_report_lines.append(pay_report_line)

#                 is_parent_unfolded = unfold_all or pay_report_line['parent_id'] in options['unfolded_lines']
#                 if not is_parent_unfolded:
#                     pay_report_line['style'] = 'display: none;'

#             return (
#                 self._build_section_report_lines(options, journal, plus_report_lines, plus_total,
#                                                  _("(+) Outstanding Receipts"),
#                                                  _("Transactions(+) that were entered into Odoo (%s), but not yet reconciled (Payments triggered by "
#                                                      "invoices/refunds or manually)") % journal.payment_debit_account_id.display_name,
#                                                  ),
#                 self._build_section_report_lines(options, journal, less_report_lines, less_total,
#                                                  _("(-) Outstanding Payments"),
#                                                  _("Transactions(-) that were entered into Odoo (%s), but not yet reconciled (Payments triggered by "
#                                                      "bills/credit notes or manually)") % journal.payment_credit_account_id.display_name,
#                                                  ),
#             )

#         @api.model
#         def _get_lines(self, options, line_id=None):
#             print_mode = self._context.get('print_mode')
#             journal_id = self._context.get('active_id') or options.get('active_id')
#             journal = self.env['account.journal'].browse(journal_id)

#             if not journal:
#                 return []

#             # Make sure to keep the 'active_id' inside the options to don't depend of the context when printing the report.
#             options['active_id'] = journal_id

#             company_currency = journal.company_id.currency_id
#             journal_currency = journal.currency_id if journal.currency_id and journal.currency_id != company_currency else False
#             report_currency = journal_currency or company_currency

#             last_statement_domain = [('date', '<=', options['date']['date_to'])]
#             if not options['all_entries']:
#                 last_statement_domain.append(('move_id.state', '=', 'posted'))
#             last_statement = journal._get_last_bank_statement(domain=last_statement_domain)

#             # === Warnings ====

#             # Unconsistent statements.
#             options['unconsistent_statement_ids'] = self._get_unconsistent_statements(options, journal).ids

#             # Strange miscellaneous journal items affecting the bank accounts.
#             domain = self._get_bank_miscellaneous_move_lines_domain(options, journal)
#             if domain:
#                 options['has_bank_miscellaneous_move_lines'] = bool(self.env['account.move.line'].search_count(domain))
#             else:
#                 options['has_bank_miscellaneous_move_lines'] = False
#             options['account_names'] = journal.default_account_id.display_name

#             # ==== Build sub-sections about journal items ====

#             plus_st_lines, less_st_lines = self._get_statement_report_lines(options, journal)
#             plus_pay_lines, less_pay_lines = self._get_payment_report_lines(options, journal)

#             # ==== Build section block about statement lines ====

#             domain = self._get_options_domain(options)
#             balance_gl = journal._get_journal_bank_account_balance(domain=domain)[0]

#             # Compute the 'Reference' cell.
#             if last_statement and not print_mode:
#                 reference_cell = {
#                     'last_statement_name': last_statement.display_name,
#                     'last_statement_id': last_statement.id,
#                     'template': 'account_reports.bank_reconciliation_report_cell_template_link_last_statement',
#                 }
#             else:
#                 reference_cell = {'name': ''}

#             # Compute the 'Amount' cell.
#             balance_cell = {
#                 'name': selfformat_value(options,value=balance_gl, report_currency),
#                 'no_format': balance_gl,
#             }
#             if last_statement:
#                 difference = balance_gl - last_statement.balance_end

#                 if not report_currency.is_zero(difference):
#                     balance_cell.update({
#                         'template': 'account_reports.bank_reconciliation_report_cell_template_unexplained_difference',
#                         'style': 'color:orange;',
#                         'title': _("The current balance in the General Ledger %s doesn't match the balance of your last "
#                                    "bank statement %s leading to an unexplained difference of %s.") % (
#                             balance_cell['name'],
#                             selfformat_value(options,value=last_statement.balance_end_real, report_currency),
#                             selfformat_value(options,value=difference, report_currency),
#                         ),
#                     })

#             balance_gl_report_line = {
#                 'id': 'balance_gl_line',
#                 'name': _("Balance of %s", options['account_names']),
#                 'title_hover': _("The Book balance in Odoo dated today"),
#                 'columns': self._apply_groups([
#                     # {'name': format_date(self.env, options['date']['date_to']), 'class': 'date'},
#                     {'name': jdatetime.datetime.fromgregorian(date=datetime.datetime.strptime(options['date']['date_to'], DEFAULT_SERVER_DATE_FORMAT)).strftime(
#                         DEFAULT_SERVER_DATE_FORMAT) if self.env.user.lang == 'fa_IR' else fd(self.env, options['date']['date_to']), 'class': 'date'},
#                     reference_cell,
#                     {'name': ''},
#                     {'name': ''},
#                     balance_cell,
#                 ]),
#                 'class': 'o_account_reports_totals_below_sections' if self.env.company.totals_below_sections else '',
#                 'level': 0,
#                 'unfolded': True,
#                 'unfoldable': False,
#             }

#             section_st_report_lines = [balance_gl_report_line] + plus_st_lines + less_st_lines

#             if self.env.company.totals_below_sections:
#                 section_st_report_lines.append({
#                     'id': '%s_total' % balance_gl_report_line,
#                     'name': _("Total %s", balance_gl_report_line['name']),
#                     'columns': balance_gl_report_line['columns'],
#                     'class': 'total',
#                     'level': balance_gl_report_line['level'] + 1,
#                 })

#             # ==== Build section block about payments ====

#             section_pay_report_lines = []

#             if plus_pay_lines or less_pay_lines:

#                 # Compute total to display for this section.
#                 total = 0.0
#                 if plus_pay_lines:
#                     total += plus_pay_lines[0]['columns'][-1]['no_format']
#                 if less_pay_lines:
#                     total += less_pay_lines[0]['columns'][-1]['no_format']

#                 outstanding_payments_report_line = {
#                     'id': 'outstanding_payments',
#                     'name': _("Outstanding Payments/Receipts"),
#                     'title_hover': _("Transactions that were entered into Odoo, but not yet reconciled (Payments triggered by invoices/bills or manually)"),
#                     'columns': self._apply_groups([
#                         {'name': ''},
#                         {'name': ''},
#                         {'name': ''},
#                         {'name': ''},
#                         {
#                             'name': selfformat_value(options,value=total, report_currency),
#                             'no_format': total,
#                         },
#                     ]),
#                     'class': 'o_account_reports_totals_below_sections' if self.env.company.totals_below_sections else '',
#                     'level': 0,
#                     'unfolded': True,
#                     'unfoldable': False,
#                 }
#                 section_pay_report_lines += [outstanding_payments_report_line] + plus_pay_lines + less_pay_lines

#                 if self.env.company.totals_below_sections:
#                     section_pay_report_lines.append({
#                         'id': '%s_total' % outstanding_payments_report_line['id'],
#                         'name': _("Total %s", outstanding_payments_report_line['name']),
#                         'columns': outstanding_payments_report_line['columns'],
#                         'class': 'total',
#                         'level': outstanding_payments_report_line['level'] + 1,
#                     })

#             # ==== Build trailing section block ====

#             return section_st_report_lines + section_pay_report_lines

        # abr.BankReconciliationReportCustomHandler._get_statement_report_lines = _get_statement_report_lines
        # abr.BankReconciliationReportCustomHandler._get_payment_report_lines = _get_payment_report_lines
        # abr.BankReconciliationReportCustomHandler._get_lines = _get_lines
