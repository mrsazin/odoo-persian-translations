# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import datetime

import jdatetime
from dateutil.relativedelta import relativedelta

from odoo import _, models
from odoo.addons.fadoo_calendar.globals import jdate_utils
from odoo.tools import end_of

DAYS_PER_MONTH = 30
DAYS_PER_YEAR = DAYS_PER_MONTH * 12

class AccountAsset(models.Model):
    _inherit = 'account.asset'

    def _get_end_period_date(self, start_depreciation_date):
        """Get the end of the period in which the depreciation is posted.

        Can be the end of the month if the asset is depreciated monthly, or the end of the fiscal year is it is depreciated yearly.
        """
        self.ensure_one()
        fiscalyear_date = self.company_id.compute_fiscalyear_dates(start_depreciation_date).get('date_to')
        period_end_depreciation_date = fiscalyear_date if start_depreciation_date < fiscalyear_date else fiscalyear_date + relativedelta(years=1)
        if self.env.user.lang == 'fa_IR':
            if self.method_period == '1': 
                max_day_in_month = (jdate_utils.jget_month(start_depreciation_date)[1]-jdate_utils.jget_month(start_depreciation_date)[0]+relativedelta(days=1)).days
                period_end_depreciation_date = jdatetime.date.fromgregorian(year=start_depreciation_date.year,month=start_depreciation_date.month,\
                    day=start_depreciation_date.day).replace(day=max_day_in_month).togregorian()
            elif self.method_period == '12': 
                jstart = jdatetime.date.fromgregorian(year=start_depreciation_date.year,month=start_depreciation_date.month,day=start_depreciation_date.day)
                mstart = jdatetime.date(year=jstart.year,month=12,day=1).togregorian()
                max_day_in_month = (jdate_utils.jget_month(mstart)[1]-jdate_utils.jget_month(mstart)[0]+relativedelta(days=1)).days
                period_end_depreciation_date = jdatetime.date.fromgregorian(year=mstart.year,month=mstart.month,\
                    day=mstart.day).replace(day=max_day_in_month).togregorian()
        else:
            if self.method_period == '1':  # If method period is set to monthly computation
                max_day_in_month = end_of(datetime.date(start_depreciation_date.year, start_depreciation_date.month, 1), 'month').day
                period_end_depreciation_date = min(start_depreciation_date.replace(day=max_day_in_month), period_end_depreciation_date)
                
        return period_end_depreciation_date
