# -*- coding: utf-8 -*-
{
    'name': "fadoo_persian_calendar_account_reports",
    'summary': """Persian Calendar""",
    'description': """Persian Calendar """,
    'author': "Fadoo",
    'website': "https://www.fadoo.ir",
    'category': 'Localization/Iran',
    'version': '1.0.1',
    'depends': ['account_reports', 'fadoo_calendar','account_asset'],
    'auto_install': True,
    'license': 'LGPL-3',
}
