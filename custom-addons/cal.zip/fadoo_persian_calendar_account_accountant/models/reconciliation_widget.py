# -*- coding: utf-8 -*-
import jdatetime

from odoo import _, api, models
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT


class FadooAccountReconciliation(models.AbstractModel):
    _inherit = 'account.reconciliation.widget'
    # TODO CHECK fadoo calendar
    @api.model
    def _prepare_js_reconciliation_widget_move_line(self, statement_line, line, recs_count=0):
        js_vals = super(FadooAccountReconciliation, self)._prepare_js_reconciliation_widget_move_line(
            statement_line, line, recs_count)
        #################################################################
        if self.env.user.lang == 'fa_IR':
            js_vals['date'] = jdatetime.datetime.fromgregorian(date=line.date).strftime(
                DEFAULT_SERVER_DATE_FORMAT) if line.date else ''
            js_vals['date_maturity'] = jdatetime.datetime.fromgregorian(date=line.date_maturity).strftime(
                DEFAULT_SERVER_DATE_FORMAT) if line.date_maturity else ''
        #################################################################
        return js_vals

    @api.model
    def _get_statement_line(self, st_line):
        data = super(FadooAccountReconciliation, self)._get_statement_line(st_line)
        #################################################################
        if self.env.user.lang == 'fa_IR':
            data['date'] = jdatetime.datetime.fromgregorian(date=st_line.date).strftime(
                DEFAULT_SERVER_DATE_FORMAT) if st_line.date else ''
        #################################################################
        return data

    @api.model
    def _prepare_move_lines(self, move_lines, target_currency=False, target_date=False, recs_count=0):
        ret = super(FadooAccountReconciliation, self)._prepare_move_lines(
            move_lines, target_currency, target_date, recs_count)
        #################################################################
        if self.env.user.lang == 'fa_IR':
            for line in ret:
                line_obj = self.env['account.move.line'].browse(line['id'])
                line['date_maturity'] = jdatetime.datetime.fromgregorian(date=line_obj.date_maturity).strftime(
                    DEFAULT_SERVER_DATE_FORMAT) if line_obj.date_maturity else ''
                line['date'] = jdatetime.datetime.fromgregorian(date=line_obj.date).strftime(
                    DEFAULT_SERVER_DATE_FORMAT) if line_obj.date else ''
        #################################################################
        return ret
