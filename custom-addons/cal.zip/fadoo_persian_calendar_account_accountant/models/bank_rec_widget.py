# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import jdatetime

from odoo import _, fields, models, tools
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, html2plaintext
from odoo.tools.misc import formatLang


class BankRecWidget(models.Model):
    _inherit = "bank.rec.widget"
    # TODO CHECK fadoo calendar
    def _compute_lines_widget(self):
        """ Convert the bank.rec.widget.line recordset (line_ids fields) to a dictionary to fill the 'lines_widget'
        owl widget.
        """
        self._check_lines_widget_consistency()

        # Protected fields by the orm like create_date should be excluded.
        protected_fields = set(models.MAGIC_COLUMNS + [self.CONCURRENCY_CHECK_FIELD])

        for wizard in self:
            lines = wizard.line_ids

            # Sort the lines.
            sorted_lines = []
            auto_balance_lines = []
            epd_lines = []
            exchange_diff_map = {x.source_aml_id: x for x in lines.filtered(lambda x: x.flag == 'exchange_diff')}
            for line in lines:
                if line.flag == 'auto_balance':
                    auto_balance_lines.append(line)
                elif line.flag == 'early_payment':
                    epd_lines.append(line)
                elif line.flag != 'exchange_diff':
                    sorted_lines.append(line)
                    if line.flag == 'new_aml' and exchange_diff_map.get(line.source_aml_id):
                        sorted_lines.append(exchange_diff_map[line.source_aml_id])

            line_vals_list = []
            for line in sorted_lines + epd_lines + auto_balance_lines:
                js_vals = {}

                for field_name, field in line._fields.items():
                    if field_name in protected_fields:
                        continue

                    value = line[field_name]
                    if field.type == 'date':
                        if self.env.user.lang == 'fa_IR':
                            js_vals[field_name] = {
                                'display': jdatetime.datetime.fromgregorian(date=value).strftime(DEFAULT_SERVER_DATE_FORMAT) if value else '',
                                'value': fields.Date.to_string(value),
                            }
                        else:
                            js_vals[field_name] = {
                                'display': tools.format_date(self.env, value),
                                'value': fields.Date.to_string(value),
                            }
                    elif field.type == 'char':
                        js_vals[field_name] = {'value': value or ''}
                    elif field.type == 'monetary':
                        currency = line[field.currency_field]
                        js_vals[field_name] = {
                            'display': formatLang(self.env, value, currency_obj=currency),
                            'value': value,
                            'is_zero': currency.is_zero(value),
                        }
                    elif field.type == 'many2one':
                        record = value._origin
                        js_vals[field_name] = {
                            'display': record.display_name or '',
                            'id': record.id,
                        }
                    elif field.type == 'many2many':
                        records = value._origin
                        js_vals[field_name] = {
                            'display': records.mapped('display_name'),
                            'ids': records.ids,
                        }
                    else:
                        js_vals[field_name] = {'value': value}
                line_vals_list.append(js_vals)

            extra_notes = []
            bank_account = wizard.st_line_id.partner_bank_id.display_name or wizard.st_line_id.account_number
            if bank_account:
                extra_notes.append(bank_account)
            narration = wizard.st_line_id.narration and html2plaintext(wizard.st_line_id.narration)
            if narration:
                extra_notes.append(narration)

            bool_analytic_distribution = False
            for line in wizard.line_ids:
                if line.analytic_distribution:
                    bool_analytic_distribution = True
                    break

            wizard.lines_widget = {
                'lines': line_vals_list,

                'display_multi_currency_column': wizard.line_ids.currency_id != wizard.company_currency_id,
                'display_taxes_column': bool(wizard.line_ids.tax_ids),
                'display_analytic_distribution_column': bool_analytic_distribution,
                'form_index': wizard.form_index,
                'state': wizard.state,
                'partner_name': wizard.st_line_id.partner_name,
                'extra_notes': ' '.join(extra_notes) if extra_notes else None,
            }