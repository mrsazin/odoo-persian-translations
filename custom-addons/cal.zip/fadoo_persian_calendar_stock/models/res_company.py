import datetime

import jdatetime

from odoo import _, fields, models, api
from odoo.addons.fadoo_calendar.models.res_company import \
    MONTH_SELECTION


class FadooResCompany(models.Model):
    _inherit = "res.company"
    
    annual_inventory_month = fields.Selection(MONTH_SELECTION, string='Annual Inventory Month',
            default='12',
            help="Annual inventory month for products not in a location with a cyclic inventory date. Set to no month if no automatic annual inventory.")
    

class FadooResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"
    
    def onchange(self, values, field_name, field_onchange):
        res = super(FadooResConfigSettings,self).onchange(values, field_name, field_onchange)
        if self.env.user.lang == 'fa_IR' and res.get('value',{}).get('annual_inventory_month'):
            end_date = jdatetime.date.fromgregorian(year=datetime.datetime.now().year,month=int(res['value']['annual_inventory_month']),day=res['value']['annual_inventory_day'])
            res['value']['annual_inventory_month'] = str(end_date.month)
            res['value']['annual_inventory_day'] = end_date.day
        return res
    
    def read(self, fields=None, load='_classic_read'):
        res = super(FadooResConfigSettings,self).read(fields, load)
        if self.env.user.lang == 'fa_IR':
            end_date = jdatetime.date.fromgregorian(year=datetime.datetime.now().year,month=int(res[0]['annual_inventory_month']),day=res[0]['annual_inventory_day'])
            res[0]['annual_inventory_month'] = str(end_date.month)
            res[0]['annual_inventory_day'] = end_date.day
        return res
    
    # def write(self, vals):
    #     if self.env.user.lang == 'fa_IR':
    #         for wiz in self:
    #             aod = datetime.datetime.now()
    #             end_date = jdatetime.date.fromgregorian(year=aod.year,
    #                                                     month=int(wiz.annual_inventory_month),
    #                                                     day=wiz.annual_inventory_day)
    #             fld = vals.get('annual_inventory_day') or end_date.day
    #             flm = vals.get('annual_inventory_month') or end_date.month
    #             jdate = jdatetime.date.togregorian(jdatetime.date(year=aod.year,month=int(flm),day=fld))
    #             flm = str(jdate.month)
    #             fld = jdate.day
    #         vals['annual_inventory_day'] = fld
    #         vals['annual_inventory_month'] = flm
    #         return super().write(vals)
    #     return super().write(vals)
    
    @api.model_create_multi
    def create(self, vals_list):
        if self.env.user.lang == 'fa_IR':
            for vals in vals_list:
                aod = datetime.datetime.now()
                end_date = jdatetime.date.fromgregorian(year=aod.year,
                                                        month=int(vals.get('annual_inventory_month',1)),
                                                        day=vals.get('annual_inventory_day',1))
                fld = vals.get('annual_inventory_day') or end_date.day
                flm = vals.get('annual_inventory_month') or end_date.month
                jdate = jdatetime.date.togregorian(jdatetime.date(year=aod.year,month=int(flm),day=fld))
                flm = str(jdate.month)
                fld = jdate.day
                vals['annual_inventory_day'] = fld
                vals['annual_inventory_month'] = flm
            return super().create(vals_list)
        return super().create(vals_list)
