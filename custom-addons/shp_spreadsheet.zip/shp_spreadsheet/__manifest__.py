# -*- coding: utf-8 -*-
{
    'name' : 'shp_spreadsheet',
    'version' : '1.0',
    'summary': 'SHP Spreadsheet Components',
    'description': """SHP Spreadsheet Components""",
    'category': 'SHP',
    'depends' : ['base', 'web'],
    'data': [
        # 'views/point_of_sale_dashboard.xml',
        # 'views/report_saledetails_custom.xml',
        # 'views/point_of_sale_report.xml',
        # 'wizard/pos_details.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
    'assets': {
        'web.assets_backend': [
            
        ],

        'spreadsheet.dependencies': [
            
        ],
        'spreadsheet.o_spreadsheet': [
            'spreadsheet/static/src/o_spreadsheet/o_spreadsheet.js',
            'shp_spreadsheet/static/src/o_spreadsheet/o_spreadsheet.js',
        ],
        'spreadsheet.assets_print': [
            
        ],
        'spreadsheet.public_spreadsheet': [
            
        ],
        'web.assets_backend': [
            
            
            
        ],
        "web.assets_web_dark": [
            
        ],
    },
}