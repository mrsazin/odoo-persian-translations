## Module <commission_plan>

#### 02.04.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Odoo CRM Commission Plan
