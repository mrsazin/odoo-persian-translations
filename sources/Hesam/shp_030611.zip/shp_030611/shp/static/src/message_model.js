/* @odoo-module */

import { Record } from "@mail/core/common/record";
import { htmlToTextContentInline } from "@mail/utils/common/format";
import { assignDefined, assignIn } from "@mail/utils/common/misc";

import { toRaw } from "@odoo/owl";

import { deserializeDateTime } from "@web/core/l10n/dates";
import { _t } from "@web/core/l10n/translation";
import { omit } from "@web/core/utils/objects";
import { url } from "@web/core/utils/urls";

import { patch } from "@web/core/utils/patch";
import { Message } from "@point_of_sale/app/store/pos_store";

const { DateTime } = luxon;

patch(Message.prototype, {
    
    now : DateTime.now().set({ milliseconds: 0 }),
    datetime : Record.attr(undefined, {
        compute() {
            debugger;
            return toRaw(this.date ? deserializeDateTime(this.date) : this.now);
        },
    }),
    get dateDay() { 
        debugger;
        let dateDay = this.datetime.toLocaleString(DateTime.DATE_FULL);
        if (dateDay === DateTime.now().toLocaleString(DateTime.DATE_FULL)) {
            dateDay = _t("Today");
        }
        return dateDay;
    },    

    get scheduledDate() {
        debugger;
        return toRaw(
            this.scheduledDatetime ? deserializeDateTime(this.scheduledDatetime) : undefined
        );
    },

    get datetimeShort() {
        debugger;
        return this.datetime.toLocaleString(DateTime.DATETIME_SHORT_WITH_SECONDS);
    },

    get editDate() {
        this.debugger;
        return this.write_date !== this.create_date ? this.write_date : false;
    },

    get editDatetimeHuge() {
        this.debugger;
        return deserializeDateTime(this.editDate).toLocaleString(
            omit(DateTime.DATETIME_HUGE, "timeZoneName")
        );
    },
});
