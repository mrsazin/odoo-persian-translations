/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { Activity } from "@mail/core/web/activity";

import { browser } from "@web/core/browser/browser";
import { deserializeDateTime } from "@web/core/l10n/dates";
import { _t } from "@web/core/l10n/translation";

const { DateTime } = luxon;

export function computeDelay(dateStr) {
    debugger;
    const today = DateTime.now().startOf("day");
    var date = moment(dateStr, 'jYYYY-jMM-jDD').format('YYYY/MM/DD'); //  moment(dateStr).format() 
    date = DateTime.fromISO(date);
    return date.diff(today, "days").days;
}

export function getMsToTomorrow() {
    const now = new Date();
    const night = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() + 1, // the next day
        0,
        0,
        0 // at 00:00:00 hours
    );
    return night.getTime() - now.getTime();
}

patch(Activity.prototype, {
    updateDelayAtNight() {
        browser.clearTimeout(this.updateDelayMidnightTimeout);
        this.updateDelayMidnightTimeout = browser.setTimeout(
            () => this.render(),
            getMsToTomorrow() + 100
        ); // Make sure there is no race condition
    },
    get delay() {
        debugger;
        return computeDelay(this.props.data.date_deadline);
    },
    get displayCreateDate() {
        debugger;
        var temp = moment().format('jYYYY/jMM/jDD HH:mm:ss');
        return deserializeDateTime(this.props.data.create_date).toLocaleString(
            luxon.DateTime.DATETIME_SHORT_WITH_SECONDS
        );
    },
});    
