/* @odoo-module */

import { Component, onWillDestroy, xml } from "@odoo/owl";

import { _t } from "@web/core/l10n/translation";

import { RelativeTime } from "@mail/core/common/relative_time";
import { patch } from "@web/core/utils/patch";

const { DateTime } = luxon;

const MINUTE = 60 * 1000;
const HOUR = 60 * MINUTE;

patch(RelativeTime.prototype,{
    computeRelativeTime() {
        
        const datetime = this.props.datetime;
        if (!datetime) {
            this.relativeTime = "";
            return;
        }
        const delta = DateTime.now().ts - datetime.ts;
        // console.log('------ relative time between: ' + DateTime.now().toISO() + " and " + datetime.toString());
        
        if (delta < 45 * 1000) {
            this.relativeTime = _t("now");
        } else {
            this.relativeTime = datetime.toRelative();
        }
        // console.log('------ is : ' + this.relativeTime);
        const updateDelay = delta < HOUR ? MINUTE : HOUR;
        if (updateDelay) {
            this.timeout = setTimeout(() => {
                this.computeRelativeTime();
                this.render();
            }, updateDelay);
        }
    }
});
