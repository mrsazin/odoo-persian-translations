/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { DateSection } from "@mail/core/common/date_section";

patch(DateSection.prototype,{
    setup() {
        this.props.date = moment().format('jYYYY/jMM/jDD'); 
    }
});
