/* @odoo-module */

import { _t } from "@web/core/l10n/translation";


import { patch } from "@web/core/utils/patch";
import { MessageService } from "@mail/core/common/message_service";

const { DateTime } = luxon; 

patch(MessageService.prototype, {
    scheduledDateSimple(message) {
        debugger;
        const result = message.scheduledDate.toLocaleString(DateTime.TIME_24_SIMPLE, {
            locale: this.userService.lang?.replace("_", "-"),
        });
        return "scheduled" + moment(result);
    },

    dateSimple(message) {
        debugger;
        const result = message.datetime.toLocaleString(DateTime.TIME_24_SIMPLE, {
            locale: this.userService.lang?.replace("_", "-"),
        });
        return "dateSimple" + moment(result);
    },


});
    

    