## Module <base_accounting_kit>

#### 06.11.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Odoo 17 Full Accounting Kit

#### 15.01.2024
#### Version 17.0.1.0.1
##### UPDT
- Bug Fix-Resolved the alignment issues.

#### 13.03.2024
#### Version 17.0.1.0.2
##### UPDT
- Bug Fix-Resolved the style issues in report templates.

#### 20.08.2024
#### Version 17.0.1.0.3
##### UPDT
- Bug Fix-Resolved the Aged Partner Balance Report.
