# -*- coding: utf-8 -*-

from . import product
from . import stock_location
from . import stock_move
from . import stock_move_line
from . import stock_orderpoint
from . import stock_picking
from . import stock_quant
from . import stock_rule
from . import stock_scrap

from . import product_replenish
from . import report_stock_quantity
from . import stock_orderpoint_snooze
from . import stock_picking_return
from . import stock_quantity_history
from . import stock_replenishment_info
from . import stock_request_count