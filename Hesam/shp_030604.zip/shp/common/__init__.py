# -*- coding: utf-8 -*-

from . import ir_qweb_fields